#!/bin/sh
set -u

SRC=/usr/local/msgsend/immsgsend.m
OUT=/usr/bin/immsgsend

echo "immsgsend build"
date
echo "version=0.2.2"
echo "sms_fallback=disabled"

if ! command -v clang >/dev/null 2>&1; then
  echo "clang missing"
  exit 0
fi

SDK=""
for d in /usr/share/SDKs/iPhoneOS.sdk /var/jb/usr/share/SDKs/iPhoneOS.sdk /var/mobile/theos/sdks/iPhoneOS*.sdk; do
  [ -d "$d" ] && { SDK="$d"; break; }
done

COMMON="-arch arm64 -miphoneos-version-min=13.0 $SRC -o $OUT -fobjc-arc -lobjc -framework Foundation"
if [ -n "$SDK" ]; then
  echo "sdk=$SDK"
  clang -isysroot "$SDK" $COMMON
else
  echo "sdk=none"
  clang $COMMON
fi

chmod 755 "$OUT"
cat > /usr/bin/msgsend <<'EOF'
#!/bin/sh
exec /usr/bin/immsgsend "$@"
EOF
chmod 755 /usr/bin/msgsend

if command -v ldid >/dev/null 2>&1; then
  ldid -S "$OUT" || true
fi

ls -lh "$OUT" /usr/bin/msgsend
exit 0
