#include <objc/runtime.h>
#include <objc/message.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

static const char *LOG_PATH = "/var/mobile/Library/Logs/sbnetprobe.log";
static const char *CMD_PATH = "/var/mobile/Library/Preferences/com.ctf.sbnetprobe.cmd";

static void log_line(const char *msg) {
    FILE *f = fopen(LOG_PATH, "a");
    if (!f) return;
    time_t t = time(NULL);
    struct tm tmv;
    localtime_r(&t, &tmv);
    char ts[32];
    strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S", &tmv);
    fprintf(f, "%s %s\n", ts, msg);
    fclose(f);
}

static id shared_wifi_manager(void) {
    Class cls = objc_getClass("SBWiFiManager");
    if (!cls) return nil;
    SEL sel = sel_registerName("sharedInstance");
    if (!class_getClassMethod(cls, sel)) return nil;
    id (*sendId)(id, SEL) = (id (*)(id, SEL))objc_msgSend;
    return sendId((id)cls, sel);
}

static int wifi_bool(id mgr, const char *selectorName, int fallback) {
    if (!mgr) return fallback;
    SEL sel = sel_registerName(selectorName);
    if (!class_getInstanceMethod(object_getClass(mgr), sel)) return fallback;
    BOOL (*sendBool)(id, SEL) = (BOOL (*)(id, SEL))objc_msgSend;
    return sendBool(mgr, sel) ? 1 : 0;
}

static void set_wifi_enabled(int enabled) {
    char line[256];
    id mgr = shared_wifi_manager();
    if (!mgr) {
        log_line("wifi_control manager_missing");
        return;
    }
    int beforeEnabled = wifi_bool(mgr, "wiFiEnabled", -1);
    int beforePowered = wifi_bool(mgr, "isPowered", -1);
    snprintf(line, sizeof(line), "wifi_control before enabled=%d powered=%d target=%d", beforeEnabled, beforePowered, enabled);
    log_line(line);

    void (*sendSetBool)(id, SEL, BOOL) = (void (*)(id, SEL, BOOL))objc_msgSend;
    SEL setEnabledSel = sel_registerName("setWiFiEnabled:");
    SEL setPoweredSel = sel_registerName("setPowered:");
    Class cls = object_getClass(mgr);
    if (class_getInstanceMethod(cls, setEnabledSel)) {
        sendSetBool(mgr, setEnabledSel, enabled ? YES : NO);
        log_line(enabled ? "wifi_control setWiFiEnabled:YES sent" : "wifi_control setWiFiEnabled:NO sent");
    } else if (class_getInstanceMethod(cls, setPoweredSel)) {
        sendSetBool(mgr, setPoweredSel, enabled ? YES : NO);
        log_line(enabled ? "wifi_control setPowered:YES sent" : "wifi_control setPowered:NO sent");
    } else {
        log_line("wifi_control setter_missing");
        return;
    }
    usleep(300000);
    int afterEnabled = wifi_bool(mgr, "wiFiEnabled", -1);
    int afterPowered = wifi_bool(mgr, "isPowered", -1);
    snprintf(line, sizeof(line), "wifi_control after enabled=%d powered=%d", afterEnabled, afterPowered);
    log_line(line);
}

static void *delayed_wifi_on_thread(void *arg) {
    int seconds = (int)(long)arg;
    if (seconds < 5) seconds = 5;
    if (seconds > 120) seconds = 120;
    sleep((unsigned int)seconds);
    log_line("wifi_failsafe restore begin");
    set_wifi_enabled(1);
    log_line("wifi_failsafe restore done");
    return NULL;
}

static void start_failsafe_restore(int seconds) {
    pthread_t th;
    if (pthread_create(&th, NULL, delayed_wifi_on_thread, (void *)(long)seconds) == 0) {
        pthread_detach(th);
    } else {
        log_line("wifi_failsafe pthread_create_failed");
    }
}

static void *wifi_set_thread(void *arg) {
    int enabled = (int)(long)arg;
    log_line(enabled ? "wifi_set begin target=1" : "wifi_set begin target=0");
    set_wifi_enabled(enabled ? 1 : 0);
    if (!enabled) start_failsafe_restore(75);
    log_line(enabled ? "wifi_set done target=1" : "wifi_set done target=0");
    return NULL;
}

static void start_wifi_set(int enabled) {
    pthread_t th;
    if (pthread_create(&th, NULL, wifi_set_thread, (void *)(long)(enabled ? 1 : 0)) == 0) {
        pthread_detach(th);
    } else {
        log_line("wifi_set pthread_create_failed");
    }
}

static void *wifi_cycle_thread(void *arg) {
    int seconds = (int)(long)arg;
    if (seconds < 1) seconds = 1;
    if (seconds > 10) seconds = 10;
    char line[128];
    snprintf(line, sizeof(line), "wifi_cycle begin seconds=%d", seconds);
    log_line(line);
    set_wifi_enabled(0);
    sleep((unsigned int)seconds);
    set_wifi_enabled(1);
    log_line("wifi_cycle restored");
    return NULL;
}

static void start_wifi_cycle(int seconds) {
    pthread_t th;
    if (pthread_create(&th, NULL, wifi_cycle_thread, (void *)(long)seconds) == 0) {
        pthread_detach(th);
    } else {
        log_line("wifi_cycle pthread_create_failed");
    }
}

static void process_command_file(void) {
    FILE *f = fopen(CMD_PATH, "r");
    if (!f) return;
    char buf[128] = {0};
    fgets(buf, sizeof(buf), f);
    fclose(f);

    int value = 0;
    if (sscanf(buf, "wifi-cycle %d", &value) == 1) {
        start_wifi_cycle(value);
    } else if (sscanf(buf, "wifi-set %d", &value) == 1) {
        start_wifi_set(value ? 1 : 0);
    }
}

static void *command_poll_thread(void *arg) {
    (void)arg;
    sleep(8);
    log_line("cmd_poll active");

    time_t last_mtime = 0;
    off_t last_size = -1;
    struct stat st;
    if (stat(CMD_PATH, &st) == 0) {
        last_mtime = st.st_mtime;
        last_size = st.st_size;
        log_line("cmd_poll ignored existing command");
    }

    for (;;) {
        if (stat(CMD_PATH, &st) == 0) {
            if (st.st_mtime != last_mtime || st.st_size != last_size) {
                last_mtime = st.st_mtime;
                last_size = st.st_size;
                process_command_file();
            }
        }
        sleep(1);
    }
    return NULL;
}

__attribute__((constructor))
static void sbnetprobe_ctor(void) {
    log_line("sbnetprobe 0.1.6 ctor entered");
    pthread_t th;
    if (pthread_create(&th, NULL, command_poll_thread, NULL) == 0) {
        pthread_detach(th);
        log_line("cmd_poll scheduled");
    } else {
        log_line("cmd_poll pthread_create_failed");
    }
}
