#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>

static const char *CMD_PATH = "/var/mobile/Library/Preferences/com.ctf.sbnetprobe.cmd";

static void usage(void) {
    puts("usage:");
    puts("  sbnetctl wifi-cycle <seconds>");
    puts("  sbnetctl wifi-off");
    puts("  sbnetctl wifi-on");
    puts("seconds is clamped by SpringBoard tweak to 1..10");
}

int main(int argc, char **argv) {
    int is_cycle = argc == 3 && strcmp(argv[1], "wifi-cycle") == 0;
    int is_off = argc == 2 && strcmp(argv[1], "wifi-off") == 0;
    int is_on = argc == 2 && strcmp(argv[1], "wifi-on") == 0;
    if (!is_cycle && !is_off && !is_on) {
        usage();
        return 2;
    }

    int seconds = is_cycle ? atoi(argv[2]) : 0;
    if (is_cycle && seconds <= 0) {
        usage();
        return 2;
    }

    mkdir("/var/mobile/Library/Preferences", 0755);
    FILE *f = fopen(CMD_PATH, "w");
    if (!f) {
        perror("open command file");
        return 1;
    }
    if (is_cycle) {
        fprintf(f, "wifi-cycle %d %ld\n", seconds, (long)time(NULL));
    } else {
        fprintf(f, "wifi-set %d %ld\n", is_on ? 1 : 0, (long)time(NULL));
    }
    fclose(f);

    if (is_cycle) {
        printf("scheduled wifi-cycle seconds=%d path=%s\n", seconds, CMD_PATH);
    } else {
        printf("scheduled %s path=%s\n", is_on ? "wifi-on" : "wifi-off", CMD_PATH);
    }
    return 0;
}
