#include <ifaddrs.h>
#include <net/if.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#if defined(__APPLE__)
#include <net/if_dl.h>
#endif

static int starts_with(const char *s, const char *p) {
    return s && p && strncmp(s, p, strlen(p)) == 0;
}

static unsigned long long pdp_total(void) {
    struct ifaddrs *ifap = NULL;
    unsigned long long total = 0;
    if (getifaddrs(&ifap) != 0) {
        perror("getifaddrs");
        return 0;
    }
    for (struct ifaddrs *ifa = ifap; ifa; ifa = ifa->ifa_next) {
        if (!ifa->ifa_name || !starts_with(ifa->ifa_name, "pdp_ip")) continue;
#if defined(__APPLE__)
        if (ifa->ifa_data) {
            const struct if_data *d = (const struct if_data *)ifa->ifa_data;
            total += (unsigned long long)d->ifi_ibytes;
            total += (unsigned long long)d->ifi_obytes;
        }
#endif
    }
    freeifaddrs(ifap);
    return total;
}

int main(int argc, char **argv) {
    int seconds = 30;
    if (argc > 1) {
        seconds = atoi(argv[1]);
        if (seconds <= 0) seconds = 30;
        if (seconds > 600) seconds = 600;
    }

    unsigned long long base = pdp_total();
    printf("cellguardwatch 0.1.5\n");
    printf("mode=read-only\n");
    printf("duration=%d\n", seconds);
    printf("base=%llu\n", base);
    fflush(stdout);

    for (int i = 1; i <= seconds; i++) {
        sleep(1);
        unsigned long long cur = pdp_total();
        unsigned long long used = cur >= base ? cur - base : 0;
        printf("t=%d current=%llu delta=%llu\n", i, cur, used);
        fflush(stdout);
    }
    return 0;
}
