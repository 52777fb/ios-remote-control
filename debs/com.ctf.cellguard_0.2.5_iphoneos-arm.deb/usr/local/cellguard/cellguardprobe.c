#include <ifaddrs.h>
#include <net/if.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined(__APPLE__)
#include <net/if_dl.h>
#endif

static int starts_with(const char *s, const char *p) {
    return s && p && strncmp(s, p, strlen(p)) == 0;
}

int main(int argc, char **argv) {
    struct ifaddrs *ifap = NULL;
    if (getifaddrs(&ifap) != 0) {
        perror("getifaddrs");
        return 1;
    }

    printf("cellguardprobe 0.1.4\n");
    printf("mode=read-only\n");
    printf("interfaces:\n");

    int pdp_count = 0;
    for (struct ifaddrs *ifa = ifap; ifa; ifa = ifa->ifa_next) {
        if (!ifa->ifa_name) continue;

        unsigned long long ibytes = 0;
        unsigned long long obytes = 0;

#if defined(__APPLE__)
        if (ifa->ifa_data) {
            const struct if_data *d = (const struct if_data *)ifa->ifa_data;
            ibytes = (unsigned long long)d->ifi_ibytes;
            obytes = (unsigned long long)d->ifi_obytes;
        }
#endif

        printf("%s flags=0x%x in=%llu out=%llu", ifa->ifa_name, ifa->ifa_flags, ibytes, obytes);
        if (starts_with(ifa->ifa_name, "pdp_ip")) {
            printf(" cellular_candidate=1");
            pdp_count++;
        }
        if (starts_with(ifa->ifa_name, "en")) {
            printf(" wifi_candidate=1");
        }
        if (starts_with(ifa->ifa_name, "utun")) {
            printf(" tunnel_candidate=1");
        }
        printf("\n");
    }

    printf("pdp_count=%d\n", pdp_count);
    freeifaddrs(ifap);
    return 0;
}
