#include <errno.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

#if defined(__APPLE__)
#include <net/if_dl.h>
#endif

static int starts_with(const char *s, const char *p) {
    return s && p && strncmp(s, p, strlen(p)) == 0;
}

static void print_flags(unsigned int f) {
    printf(" flags=0x%x", f);
    if (f & IFF_UP) printf(" UP");
    if (f & IFF_RUNNING) printf(" RUNNING");
    if (f & IFF_LOOPBACK) printf(" LOOPBACK");
    if (f & IFF_POINTOPOINT) printf(" POINTOPOINT");
    if (f & IFF_BROADCAST) printf(" BROADCAST");
    if (f & IFF_MULTICAST) printf(" MULTICAST");
}

static int ioctl_get_flags(int s, const char *name, short *out) {
    struct ifreq ifr;
    memset(&ifr, 0, sizeof(ifr));
    snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", name);
    if (ioctl(s, SIOCGIFFLAGS, &ifr) != 0) return -1;
    *out = ifr.ifr_flags;
    return 0;
}

static void log_line(const char *msg) {
    FILE *f = fopen("/var/mobile/Library/Logs/cellguardifctl.log", "a");
    if (!f) return;
    time_t t = time(NULL);
    struct tm tmv;
    localtime_r(&t, &tmv);
    char ts[32];
    strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S", &tmv);
    fprintf(f, "%s %s\n", ts, msg);
    fclose(f);
}

static int set_if_up(const char *name, int up) {
    int s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0) return -1;

    struct ifreq ifr;
    memset(&ifr, 0, sizeof(ifr));
    snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", name);
    if (ioctl(s, SIOCGIFFLAGS, &ifr) != 0) {
        close(s);
        return -1;
    }

    if (up) ifr.ifr_flags |= IFF_UP;
    else ifr.ifr_flags &= ~IFF_UP;

    int ret = ioctl(s, SIOCSIFFLAGS, &ifr);
    close(s);
    return ret;
}

static int wifi_cycle_child(int seconds) {
    char msg[128];
    snprintf(msg, sizeof(msg), "wifi-cycle child scheduled seconds=%d", seconds);
    log_line(msg);

    sleep(1);
    if (set_if_up("en0", 0) == 0) {
        log_line("wifi-cycle en0 down ok");
    } else {
        snprintf(msg, sizeof(msg), "wifi-cycle en0 down fail errno=%d %s", errno, strerror(errno));
        log_line(msg);
    }

    sleep((unsigned int)seconds);
    if (set_if_up("en0", 1) == 0) {
        log_line("wifi-cycle en0 up ok");
    } else {
        snprintf(msg, sizeof(msg), "wifi-cycle en0 up fail errno=%d %s", errno, strerror(errno));
        log_line(msg);
    }
    return 0;
}

static int wifi_cycle(int seconds) {
    if (seconds < 1) seconds = 1;
    if (seconds > 5) seconds = 5;

    pid_t pid = fork();
    if (pid < 0) {
        printf("wifi_cycle=fork_fail errno=%d %s\n", errno, strerror(errno));
        return 1;
    }
    if (pid == 0) {
        setsid();
        close(STDIN_FILENO);
        close(STDOUT_FILENO);
        close(STDERR_FILENO);
        return wifi_cycle_child(seconds);
    }

    printf("cellguardifctl 0.2.0\n");
    printf("wifi_cycle=scheduled\n");
    printf("interface=en0\n");
    printf("down_after_seconds=1\n");
    printf("restore_after_down_seconds=%d\n", seconds);
    printf("child_pid=%ld\n", (long)pid);
    printf("log=/var/mobile/Library/Logs/cellguardifctl.log\n");
    return 0;
}

static int probe(void) {
    printf("cellguardifctl 0.2.0\n");
    printf("mode=read-only-control-probe\n");

    int s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0) {
        printf("control_socket=fail errno=%d %s\n", errno, strerror(errno));
        return 1;
    }
    printf("control_socket=ok\n");

    struct ifaddrs *ifap = NULL;
    if (getifaddrs(&ifap) != 0) {
        printf("getifaddrs=fail errno=%d %s\n", errno, strerror(errno));
        close(s);
        return 1;
    }

    int pdp = 0, wifi = 0;
    for (struct ifaddrs *ifa = ifap; ifa; ifa = ifa->ifa_next) {
        if (!ifa->ifa_name) continue;
        const char *name = ifa->ifa_name;
        if (!starts_with(name, "pdp_ip") && strcmp(name, "en0") != 0) continue;

        short fl = 0;
        int ok = ioctl_get_flags(s, name, &fl);
        if (starts_with(name, "pdp_ip")) pdp++;
        if (strcmp(name, "en0") == 0) wifi++;
        printf("%s", name);
        if (ok == 0) {
            print_flags((unsigned int)fl);
            printf(" ioctl_get=ok");
        } else {
            printf(" ioctl_get=fail errno=%d %s", errno, strerror(errno));
        }
#if defined(__APPLE__)
        if (ifa->ifa_data) {
            const struct if_data *d = (const struct if_data *)ifa->ifa_data;
            printf(" in=%llu out=%llu",
                   (unsigned long long)d->ifi_ibytes,
                   (unsigned long long)d->ifi_obytes);
        }
#endif
        printf("\n");
    }

    freeifaddrs(ifap);
    close(s);
    printf("pdp_candidates=%d\n", pdp);
    printf("wifi_en0_entries=%d\n", wifi);
    printf("safe_result=no_network_change\n");
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 2 || strcmp(argv[1], "probe") == 0) {
        return probe();
    }
    if (strcmp(argv[1], "wifi-cycle") == 0) {
        int seconds = 2;
        if (argc >= 3) seconds = atoi(argv[2]);
        return wifi_cycle(seconds);
    }
    fprintf(stderr, "usage: cellguardifctl probe|wifi-cycle [seconds]\n");
    return 2;
}
