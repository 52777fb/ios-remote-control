#!/bin/sh
set -u
SRC=/usr/local/cellguard/cellguardifctl.c
OUT=/usr/bin/cellguardifctl

echo "cellguard build ifctl"
date

if ! command -v clang >/dev/null 2>&1; then
  echo "clang missing"
  exit 0
fi

SDK=""
for d in /usr/share/SDKs/iPhoneOS.sdk /var/jb/usr/share/SDKs/iPhoneOS.sdk /var/mobile/theos/sdks/iPhoneOS*.sdk; do
  [ -d "$d" ] && { SDK="$d"; break; }
done

if [ -n "$SDK" ]; then
  echo "sdk=$SDK"
  clang -arch arm64 -isysroot "$SDK" -miphoneos-version-min=13.0 "$SRC" -o "$OUT"
else
  echo "sdk=none"
  clang "$SRC" -o "$OUT"
fi

chmod 755 "$OUT"
if command -v ldid >/dev/null 2>&1; then
  ldid -S "$OUT" || true
fi

"$OUT" probe | head -n 20 || true
exit 0

