#include <CoreFoundation/CoreFoundation.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <spawn.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#if defined(__APPLE__)
#include <net/if_dl.h>
#endif

#define PREF "/var/mobile/Library/Preferences/com.ctf.cellguard.plist"
#define STATE "/var/mobile/Library/Preferences/com.ctf.cellguard.state"
#define LOG "/var/mobile/Library/Logs/cellguardd.log"
#define LIMIT_BYTES 1048576ULL
#define LIMIT_SECONDS 60
#define SBNETCTL "/usr/bin/sbnetctl"

extern char **environ;

static int starts_with(const char *s, const char *p) {
    return s && p && strncmp(s, p, strlen(p)) == 0;
}

static void log_line(const char *msg) {
    FILE *f = fopen(LOG, "a");
    if (!f) return;
    time_t t = time(NULL);
    struct tm tmv;
    localtime_r(&t, &tmv);
    char ts[32];
    strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S", &tmv);
    fprintf(f, "%s %s\n", ts, msg);
    fclose(f);
}

static unsigned long long pdp_total(void) {
    struct ifaddrs *ifap = NULL;
    unsigned long long total = 0;
    if (getifaddrs(&ifap) != 0) return 0;
    for (struct ifaddrs *ifa = ifap; ifa; ifa = ifa->ifa_next) {
        if (!ifa->ifa_name || !starts_with(ifa->ifa_name, "pdp_ip")) continue;
#if defined(__APPLE__)
        if (ifa->ifa_data) {
            const struct if_data *d = (const struct if_data *)ifa->ifa_data;
            total += (unsigned long long)d->ifi_ibytes;
            total += (unsigned long long)d->ifi_obytes;
        }
#endif
    }
    freeifaddrs(ifap);
    return total;
}

static int read_pref_bool(CFDictionaryRef dict, CFStringRef key) {
    CFTypeRef v = CFDictionaryGetValue(dict, key);
    return v && CFGetTypeID(v) == CFBooleanGetTypeID() && v == kCFBooleanTrue;
}

static int read_prefs(int *out_restore) {
    if (out_restore) *out_restore = 0;
    CFStringRef path = CFStringCreateWithCString(kCFAllocatorDefault, PREF, kCFStringEncodingUTF8);
    CFURLRef url = CFURLCreateWithFileSystemPath(kCFAllocatorDefault, path, kCFURLPOSIXPathStyle, false);
    CFRelease(path);
    if (!url) return 0;
    CFDataRef data = NULL;
    SInt32 err = 0;
    Boolean ok = CFURLCreateDataAndPropertiesFromResource(kCFAllocatorDefault, url, &data, NULL, NULL, &err);
    CFRelease(url);
    if (!ok || !data) return 0;
    CFPropertyListRef plist = CFPropertyListCreateWithData(kCFAllocatorDefault, data, kCFPropertyListImmutable, NULL, NULL);
    CFRelease(data);
    if (!plist) return 0;
    int ret = 0;
    if (CFGetTypeID(plist) == CFDictionaryGetTypeID()) {
        CFDictionaryRef dict = (CFDictionaryRef)plist;
        ret = read_pref_bool(dict, CFSTR("enabled"));
        if (out_restore) *out_restore = read_pref_bool(dict, CFSTR("restoreWiFi"));
    }
    CFRelease(plist);
    return ret;
}

static void write_prefs_false(void) {
    const char *xml =
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
        "<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n"
        "<plist version=\"1.0\"><dict><key>enabled</key><false/><key>restoreWiFi</key><false/></dict></plist>\n";
    FILE *f = fopen(PREF, "w");
    if (!f) return;
    fputs(xml, f);
    fclose(f);
}

static void run_network_command(const char *arg) {
    char line[256];
    if (access(SBNETCTL, X_OK) != 0) {
        snprintf(line, sizeof(line), "network command skipped: %s missing", SBNETCTL);
        log_line(line);
        return;
    }
    pid_t pid = 0;
    char *argv[] = {(char *)SBNETCTL, (char *)arg, NULL};
    int rc = posix_spawn(&pid, SBNETCTL, NULL, NULL, argv, environ);
    int status = -1;
    if (rc == 0) {
        waitpid(pid, &status, 0);
    }
    snprintf(line, sizeof(line), "network command spawn_rc=%d status=%d arg=%s", rc, status, arg);
    log_line(line);
}

static void wifi_off(void) {
    run_network_command("wifi-off");
}

static void wifi_on(void) {
    run_network_command("wifi-on");
}

static void write_state(int active, time_t start, unsigned long long base, unsigned long long used, const char *reason) {
    FILE *f = fopen(STATE, "w");
    if (!f) return;
    time_t now = time(NULL);
    if (active) {
        fprintf(f, "active=1\nstart=%ld\nbase=%llu\nused=%llu\nelapsed=%ld\nreason=%s\n",
                (long)start, base, used, (long)(now - start), reason);
    } else {
        fprintf(f, "active=0\nend=%ld\nbase=%llu\nused=%llu\nreason=%s\n",
                (long)now, base, used, reason);
    }
    fclose(f);
}

int main(void) {
    log_line("cellguardd-native 0.2.5 started");
    int active = 0;
    time_t start = 0;
    unsigned long long base = 0;

    for (;;) {
        int restore = 0;
        int is_enabled = read_prefs(&restore);
        if (restore) {
            write_prefs_false();
            if (active) {
                unsigned long long cur = pdp_total();
                unsigned long long used = cur >= base ? cur - base : 0;
                write_state(0, start, base, used, "restore");
                log_line("session end restore");
                active = 0;
            } else {
                write_state(0, time(NULL), pdp_total(), 0, "restore");
                log_line("restore requested while inactive");
            }
            wifi_on();
            sleep(2);
            continue;
        }

        if (is_enabled) {
            if (!active) {
                active = 1;
                start = time(NULL);
                base = pdp_total();
                write_state(1, start, base, 0, "running");
                log_line("session start");
                wifi_off();
            }

            unsigned long long cur = pdp_total();
            unsigned long long used = cur >= base ? cur - base : 0;
            time_t now = time(NULL);
            write_state(1, start, base, used, "running");

            if (used >= LIMIT_BYTES) {
                write_prefs_false();
                write_state(0, start, base, used, "limit");
                log_line("session end limit");
                wifi_on();
                active = 0;
            } else if ((now - start) >= LIMIT_SECONDS) {
                write_prefs_false();
                write_state(0, start, base, used, "timeout");
                log_line("session end timeout");
                wifi_on();
                active = 0;
            }
        } else {
            if (active) {
                unsigned long long cur = pdp_total();
                unsigned long long used = cur >= base ? cur - base : 0;
                write_state(0, start, base, used, "manual");
                log_line("session end manual");
                wifi_on();
                active = 0;
            }
        }
        sleep(2);
    }
    return 0;
}
