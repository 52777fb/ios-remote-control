#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

static int write_all(int fd, const unsigned char *buf, size_t len) {
  size_t off = 0;
  while (off < len) {
    ssize_t n = send(fd, buf + off, len - off, 0);
    if (n <= 0) {
      return -1;
    }
    off += (size_t)n;
  }
  return 0;
}

static int connect_ws(void) {
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if (fd < 0) {
    perror("socket");
    return -1;
  }

  struct sockaddr_in addr;
  memset(&addr, 0, sizeof(addr));
  addr.sin_family = AF_INET;
  addr.sin_port = htons(58587);
  if (inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr) != 1) {
    perror("inet_pton");
    close(fd);
    return -1;
  }

  if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
    perror("connect 127.0.0.1:58587");
    close(fd);
    return -1;
  }

  const char *req =
      "GET / HTTP/1.1\r\n"
      "Host: 127.0.0.1:58587\r\n"
      "Upgrade: websocket\r\n"
      "Connection: Upgrade\r\n"
      "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\n"
      "Sec-WebSocket-Version: 13\r\n"
      "Origin: http://127.0.0.1:58586\r\n"
      "\r\n";
  if (write_all(fd, (const unsigned char *)req, strlen(req)) < 0) {
    perror("send handshake");
    close(fd);
    return -1;
  }

  char buf[2048];
  ssize_t n = recv(fd, buf, sizeof(buf) - 1, 0);
  if (n <= 0) {
    perror("recv handshake");
    close(fd);
    return -1;
  }
  buf[n] = '\0';
  if (strstr(buf, " 101 ") == NULL && strstr(buf, " 101\r") == NULL) {
    fprintf(stderr, "bad websocket handshake:\n%s\n", buf);
    close(fd);
    return -1;
  }
  return fd;
}

static int send_text_frame(int fd, const char *text) {
  size_t len = strlen(text);
  if (len >= 126) {
    fprintf(stderr, "payload too long\n");
    return -1;
  }

  unsigned char header[6];
  const unsigned char mask[4] = {0x12, 0x34, 0x56, 0x78};
  header[0] = 0x81;
  header[1] = 0x80 | (unsigned char)len;
  memcpy(header + 2, mask, sizeof(mask));

  unsigned char payload[256];
  for (size_t i = 0; i < len; i++) {
    payload[i] = ((unsigned char)text[i]) ^ mask[i % 4];
  }

  if (write_all(fd, header, sizeof(header)) < 0) {
    perror("send frame header");
    return -1;
  }
  if (write_all(fd, payload, len) < 0) {
    perror("send frame payload");
    return -1;
  }
  return 0;
}

int main(int argc, char **argv) {
  if (argc > 1 && strcmp(argv[1], "--help") == 0) {
    puts("usage: rcwake");
    puts("sends remote-control LockUnLock action over ws://127.0.0.1:58587/");
    return 0;
  }

  int fd = connect_ws();
  if (fd < 0) {
    return 1;
  }

  const char *down = "{\"down\":1,\"type\":\"action\",\"action\":3}";
  const char *up = "{\"down\":0,\"type\":\"action\",\"action\":3}";

  if (send_text_frame(fd, down) < 0) {
    close(fd);
    return 1;
  }
  usleep(120000);
  if (send_text_frame(fd, up) < 0) {
    close(fd);
    return 1;
  }

  close(fd);
  puts("ok");
  return 0;
}

