#!/bin/sh
set -u

SRC=/usr/local/rcwake/rcwake.c
OUT=/usr/local/rcwake/rcwake-native

echo "rcwake build"
date

if ! command -v clang >/dev/null 2>&1; then
  echo "clang missing"
  exit 0
fi

SDK=""
for d in /usr/share/SDKs/iPhoneOS.sdk /var/jb/usr/share/SDKs/iPhoneOS.sdk /var/mobile/theos/sdks/iPhoneOS*.sdk; do
  if [ -d "$d" ]; then
    SDK="$d"
    break
  fi
done

if [ -n "$SDK" ]; then
  echo "sdk=$SDK"
  clang -arch arm64 -isysroot "$SDK" -miphoneos-version-min=13.0 "$SRC" -o "$OUT"
else
  echo "sdk=none"
  clang "$SRC" -o "$OUT"
fi

chmod 755 "$OUT"
if command -v ldid >/dev/null 2>&1; then
  ldid -S "$OUT" || true
fi

ls -l "$OUT"
"$OUT" --help || true
exit 0

