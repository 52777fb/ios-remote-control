(function () {
  "use strict";

  var gestureSocket = null;
  var pendingMessages = [];
  var remoteWidth = 0;
  var remoteHeight = 0;

  function log(message) {
    var box = document.getElementById("log-box");
    var line = new Date().toLocaleTimeString() + " " + message;
    if (window.console && console.log) console.log("[rc]", message);
    if (!box) return;
    box.textContent += line + "\n";
    box.scrollTop = box.scrollHeight;
  }

  function connectGestureSocket() {
    if (gestureSocket && gestureSocket.readyState === WebSocket.OPEN) return;
    if (gestureSocket && gestureSocket.readyState === WebSocket.CONNECTING) return;
    var host = location.hostname || "127.0.0.1";
    var url = "ws://" + host + ":58587/";
    log("ws connecting " + url);
    gestureSocket = new WebSocket(url);
    gestureSocket.binaryType = "arraybuffer";
    gestureSocket.onopen = function () {
      log("ws open, queued=" + pendingMessages.length);
      while (pendingMessages.length && gestureSocket.readyState === WebSocket.OPEN) {
        var queued = pendingMessages.shift();
        gestureSocket.send(JSON.stringify(queued));
        log("sent queued type=" + queued.type);
      }
    };
    gestureSocket.onmessage = function (event) {
      if (typeof event.data !== "string") return;
      log("ws text recv " + event.data.slice(0, 120));
      try {
        var msg = JSON.parse(event.data);
        if (msg && msg.width && msg.height) {
          remoteWidth = Number(msg.width) || remoteWidth;
          remoteHeight = Number(msg.height) || remoteHeight;
          log("hello size=" + remoteWidth + "x" + remoteHeight);
        }
      } catch (e) {
        log("json parse failed");
      }
    };
    gestureSocket.onerror = function () {
      log("ws error");
    };
    gestureSocket.onclose = function () {
      log("ws close");
      gestureSocket = null;
    };
  }

  function sendMessage(message) {
    connectGestureSocket();
    var payload = JSON.stringify(message);
    log("send request type=" + message.type + " bytes=" + payload.length + " preview=" + payload.slice(0, 120));
    if (!gestureSocket || gestureSocket.readyState !== WebSocket.OPEN) {
      pendingMessages.push(message);
      log("queued because ws state=" + (gestureSocket ? gestureSocket.readyState : "null"));
      return false;
    }
    gestureSocket.send(payload);
    log("sent now type=" + message.type);
    return true;
  }

  function setTextStatus(text) {
    var el = document.getElementById("text-status");
    if (el) el.textContent = text || "";
  }

  function sendTextToPhone(text, reason) {
    if (!text) {
      log("text empty, skip");
      return false;
    }
    log("send text reason=" + reason + " chars=" + text.length);
    sendMessage({ type: "text", text: text, delay: 0.035 });
    return true;
  }

  function sendText() {
    var box = document.getElementById("text-input");
    var text = box ? box.value : "";
    log("button send clicked, value chars=" + text.length);
    if (!text) {
      setTextStatus("\u6ca1\u6709\u6587\u672c");
      return;
    }
    sendTextToPhone(text, "button");
    setTextStatus("\u5df2\u53d1\u9001");
  }

  function canvasPoint() {
    var canvas = document.getElementById("all_canvas");
    return {
      x: Math.round((remoteWidth || (canvas && canvas.width) || 500) / 2),
      y: Math.round((remoteHeight || (canvas && canvas.height) || 400) / 2)
    };
  }

  function pinch(kind) {
    var center = canvasPoint();
    var base = Math.max(80, Math.min(remoteWidth || 500, remoteHeight || 400) * 0.16);
    var start = kind === "out" ? base * 0.35 : base * 1.35;
    var end = kind === "out" ? base * 1.35 : base * 0.35;
    var frames = [];
    var count = 16;
    for (var i = 0; i <= count; i++) {
      var d = Math.round(start + (end - start) * (i / count));
      frames.push({
        p1: { id: 1, x: center.x - d, y: center.y },
        p2: { id: 2, x: center.x + d, y: center.y }
      });
    }
    log("pinch " + kind);
    sendMessage({
      type: "gesture",
      gesture: kind === "out" ? "pinch_out" : "pinch_in",
      action: "pinch",
      center: center,
      frames: frames
    });
  }

  function bind(id, fn) {
    var el = document.getElementById(id);
    if (el) {
      el.addEventListener("click", fn);
      log("bound " + id);
    } else {
      log("missing " + id);
    }
  }

  document.addEventListener("DOMContentLoaded", function () {
    log("dom ready");
    connectGestureSocket();
    bind("pinch-out-button", function () { pinch("out"); });
    bind("pinch-in-button", function () { pinch("in"); });
    bind("text-send-button", sendText);
    bind("log-clear-button", function () {
      var box = document.getElementById("log-box");
      if (box) box.textContent = "";
    });

    var box = document.getElementById("text-input");
    if (box) {
      box.addEventListener("input", function (event) {
        var inputType = event && event.inputType ? event.inputType : "unknown";
        log("input event type=" + inputType + " chars=" + box.value.length);
      });
      box.addEventListener("paste", function (event) {
        var text = "";
        if (event.clipboardData && event.clipboardData.getData) {
          text = event.clipboardData.getData("text/plain");
        }
        log("paste event clipboard chars=" + text.length);
        setTimeout(function () {
          if (!text) text = box.value || "";
          log("paste deferred chars=" + text.length);
        }, 0);
      });
    } else {
      log("missing text-input");
    }
  });
})();
