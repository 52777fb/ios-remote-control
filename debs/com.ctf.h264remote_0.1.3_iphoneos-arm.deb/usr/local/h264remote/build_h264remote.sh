#!/bin/sh
set -u

SRC=/usr/local/h264remote/h264remote.m
OUT=/Library/MobileSubstrate/DynamicLibraries/h264remote.dylib

echo "h264remote build"
date
echo "version=0.1.3"

if ! command -v clang >/dev/null 2>&1; then
  echo "clang missing"
  exit 0
fi

SDK=""
for d in /usr/share/SDKs/iPhoneOS.sdk /var/jb/usr/share/SDKs/iPhoneOS.sdk /var/mobile/theos/sdks/iPhoneOS*.sdk; do
  [ -d "$d" ] && { SDK="$d"; break; }
done

mkdir -p /Library/MobileSubstrate/DynamicLibraries

COMMON="-arch arm64 -miphoneos-version-min=13.0 -dynamiclib $SRC -o $OUT -fobjc-arc -fblocks -lobjc -lpthread -framework Foundation -framework UIKit -framework CoreGraphics -framework CoreVideo -framework CoreMedia -framework VideoToolbox"
if [ -n "$SDK" ]; then
  echo "sdk=$SDK"
  clang -isysroot "$SDK" $COMMON
else
  echo "sdk=none"
  clang $COMMON
fi

chmod 755 "$OUT"
if command -v ldid >/dev/null 2>&1; then
  ldid -S "$OUT" || true
fi

ls -lh "$OUT"
exit 0
