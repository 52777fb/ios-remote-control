#import <Foundation/Foundation.h>

static NSString *CmdPath(void) { return @"/var/mobile/Library/Preferences/com.ctf.immsgbridge.cmd.plist"; }
static NSString *ResultPath(void) { return @"/var/mobile/Library/Preferences/com.ctf.immsgbridge.result.plist"; }

static NSString *ArgString(char *arg) {
    NSString *s = [[NSString alloc] initWithBytes:arg length:strlen(arg) encoding:NSUTF8StringEncoding];
    return s ?: [NSString stringWithUTF8String:arg] ?: @"";
}

static NSString *JoinText(int argc, char **argv) {
    NSMutableArray *parts = [NSMutableArray array];
    for (int i = 2; i < argc; i++) [parts addObject:ArgString(argv[i])];
    return [parts componentsJoinedByString:@" "];
}

int main(int argc, char **argv) {
    @autoreleasepool {
        if (argc < 3) {
            fprintf(stderr, "usage: immsgsend <iMessage-recipient-phone-or-appleid> <text>\n");
            fprintf(stderr, "SMS fallback is disabled.\n");
            return 2;
        }
        NSString *to = ArgString(argv[1]);
        NSString *text = JoinText(argc, argv);
        NSString *nonce = [NSString stringWithFormat:@"%lld-%d", (long long)[[NSDate date] timeIntervalSince1970], getpid()];
        NSDictionary *cmd = @{
            @"nonce": nonce,
            @"status": @"pending",
            @"to": to,
            @"text": text,
            @"created": @([[NSDate date] timeIntervalSince1970])
        };
        [[NSFileManager defaultManager] createDirectoryAtPath:[CmdPath() stringByDeletingLastPathComponent] withIntermediateDirectories:YES attributes:nil error:nil];
        if (![cmd writeToFile:CmdPath() atomically:YES]) {
            fprintf(stderr, "failed to write command\n");
            return 1;
        }
        printf("queued iMessage-only command nonce=%s\n", nonce.UTF8String);
        printf("open Messages app if bridge is not active, then check:\n");
        printf("  cat /var/mobile/Library/Logs/immsgbridge.log\n");
        printf("  cat /var/mobile/Library/Preferences/com.ctf.immsgbridge.result.plist\n");
        return 0;
    }
}
