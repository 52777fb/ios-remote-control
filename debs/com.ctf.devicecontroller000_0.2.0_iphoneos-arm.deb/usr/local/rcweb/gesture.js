(function () {
  "use strict";

  var gestureSocket = null;
  var pendingMessages = [];
  var remoteWidth = 0;
  var remoteHeight = 0;

  function connectGestureSocket() {
    if (gestureSocket && gestureSocket.readyState === WebSocket.OPEN) return;
    if (gestureSocket && gestureSocket.readyState === WebSocket.CONNECTING) return;
    var host = location.hostname || "127.0.0.1";
    gestureSocket = new WebSocket("ws://" + host + ":58587/");
    gestureSocket.binaryType = "arraybuffer";
    gestureSocket.onopen = function () {
      while (pendingMessages.length && gestureSocket.readyState === WebSocket.OPEN) {
        gestureSocket.send(JSON.stringify(pendingMessages.shift()));
      }
    };
    gestureSocket.onmessage = function (event) {
      if (typeof event.data !== "string") return;
      try {
        var msg = JSON.parse(event.data);
        if (msg && msg.width && msg.height) {
          remoteWidth = Number(msg.width) || remoteWidth;
          remoteHeight = Number(msg.height) || remoteHeight;
        }
      } catch (_) {}
    };
    gestureSocket.onclose = function () {
      gestureSocket = null;
    };
  }

  function sendGesture(message) {
    connectGestureSocket();
    if (!gestureSocket || gestureSocket.readyState !== WebSocket.OPEN) {
      pendingMessages.push(message);
      return false;
    }
    gestureSocket.send(JSON.stringify(message));
    return true;
  }

  function setTextStatus(text) {
    var el = document.getElementById("text-status");
    if (el) el.textContent = text || "";
  }

  function sendText() {
    var box = document.getElementById("text-input");
    var text = box ? box.value : "";
    if (!text) {
      setTextStatus("没有文本");
      return;
    }
    sendGesture({ type: "text", text: text, delay: 0.035 });
    setTextStatus("已发送");
  }

  function canvasPoint() {
    var canvas = document.getElementById("all_canvas");
    return {
      x: Math.round((remoteWidth || (canvas && canvas.width) || 500) / 2),
      y: Math.round((remoteHeight || (canvas && canvas.height) || 400) / 2)
    };
  }

  function pinch(kind) {
    var center = canvasPoint();
    var base = Math.max(80, Math.min(remoteWidth || 500, remoteHeight || 400) * 0.16);
    var start = kind === "out" ? base * 0.35 : base * 1.35;
    var end = kind === "out" ? base * 1.35 : base * 0.35;
    var frames = [];
    var count = 16;
    for (var i = 0; i <= count; i++) {
      var d = Math.round(start + (end - start) * (i / count));
      frames.push({
        p1: { id: 1, x: center.x - d, y: center.y },
        p2: { id: 2, x: center.x + d, y: center.y }
      });
    }
    sendGesture({
      type: "gesture",
      gesture: kind === "out" ? "pinch_out" : "pinch_in",
      action: "pinch",
      center: center,
      frames: frames
    });
  }

  function bind(id, fn) {
    var el = document.getElementById(id);
    if (el) el.addEventListener("click", fn);
  }

  document.addEventListener("DOMContentLoaded", function () {
    connectGestureSocket();
    bind("pinch-out-button", function () { pinch("out"); });
    bind("pinch-in-button", function () { pinch("in"); });
    bind("text-send-button", sendText);
  });
})();
