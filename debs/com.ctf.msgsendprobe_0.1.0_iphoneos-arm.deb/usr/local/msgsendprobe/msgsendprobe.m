#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <dlfcn.h>

static BOOL containsAny(NSString *s, NSArray<NSString *> *needles) {
  for (NSString *n in needles) {
    if ([s rangeOfString:n options:NSCaseInsensitiveSearch].location != NSNotFound) return YES;
  }
  return NO;
}

static void loadFramework(NSString *path) {
  void *h = dlopen(path.UTF8String, RTLD_NOW);
  printf("dlopen %s => %s\n", path.UTF8String, h ? "ok" : (dlerror() ?: "fail"));
}

static void printMethods(Class cls, BOOL meta) {
  unsigned int count = 0;
  Method *methods = class_copyMethodList(meta ? object_getClass(cls) : cls, &count);
  NSMutableArray *names = [NSMutableArray array];
  NSArray *interesting = @[
    @"send", @"message", @"chat", @"compose", @"account", @"service",
    @"guid", @"handle", @"recipient", @"text", @"part", @"create"
  ];
  for (unsigned int i = 0; i < count; i++) {
    SEL sel = method_getName(methods[i]);
    NSString *name = NSStringFromSelector(sel);
    if (containsAny(name, interesting)) [names addObject:name];
  }
  free(methods);
  if (names.count == 0) return;
  [names sortUsingSelector:@selector(compare:)];
  printf("  %s methods=%lu\n", meta ? "class" : "inst", (unsigned long)names.count);
  NSUInteger limit = MIN((NSUInteger)80, names.count);
  for (NSUInteger i = 0; i < limit; i++) {
    printf("    %s\n", [names[i] UTF8String]);
  }
}

static void inspectClass(NSString *name) {
  Class cls = NSClassFromString(name);
  if (!cls) return;
  printf("\nTARGET %s present\n", name.UTF8String);
  printMethods(cls, YES);
  printMethods(cls, NO);
}

int main(int argc, char **argv) {
  @autoreleasepool {
    printf("msgsendprobe 0.1.0\n");
    loadFramework(@"/System/Library/PrivateFrameworks/IMCore.framework/IMCore");
    loadFramework(@"/System/Library/PrivateFrameworks/ChatKit.framework/ChatKit");
    loadFramework(@"/System/Library/Frameworks/CoreTelephony.framework/CoreTelephony");
    loadFramework(@"/System/Library/PrivateFrameworks/IMFoundation.framework/IMFoundation");

    NSArray *targets = @[
      @"IMDaemonController", @"IMChatRegistry", @"IMChat", @"IMMessage",
      @"IMMessageItem", @"IMHandle", @"IMAccount", @"IMAccountController",
      @"IMService", @"IMServiceImpl", @"IMDMessageStore",
      @"CKConversation", @"CKConversationList", @"CKIMMessage",
      @"CTMessageCenter", @"CTMessage", @"CTMessagePart"
    ];
    for (NSString *t in targets) inspectClass(t);

    int n = objc_getClassList(NULL, 0);
    Class *classes = (Class *)calloc((size_t)n, sizeof(Class));
    objc_getClassList(classes, n);
    NSArray *classNeedles = @[
      @"IMChat", @"IMMessage", @"IMDaemon", @"IMAccount", @"IMHandle",
      @"IMService", @"IMD", @"CKConversation", @"SMS", @"MessageCenter",
      @"Telephony", @"CTMessage"
    ];
    NSMutableArray *matched = [NSMutableArray array];
    for (int i = 0; i < n; i++) {
      NSString *name = @(class_getName(classes[i]));
      if (containsAny(name, classNeedles)) [matched addObject:name];
    }
    free(classes);
    [matched sortUsingSelector:@selector(compare:)];
    printf("\nmatched_classes=%lu\n", (unsigned long)matched.count);
    NSUInteger limit = MIN((NSUInteger)300, matched.count);
    for (NSUInteger i = 0; i < limit; i++) {
      printf("class=%s\n", [matched[i] UTF8String]);
    }
    printf("safe_result=read_only_no_send\n");
  }
  return 0;
}
