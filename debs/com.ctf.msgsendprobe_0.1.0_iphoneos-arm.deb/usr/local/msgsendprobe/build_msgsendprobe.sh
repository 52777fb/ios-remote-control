#!/bin/sh
set -u

SRC=/usr/local/msgsendprobe/msgsendprobe.m
OUT=/usr/bin/msgsendprobe

echo "msgsendprobe build"
date
echo "version=0.1.0"

if ! command -v clang >/dev/null 2>&1; then
  echo "clang missing"
  exit 0
fi

SDK=""
for d in /usr/share/SDKs/iPhoneOS.sdk /var/jb/usr/share/SDKs/iPhoneOS.sdk /var/mobile/theos/sdks/iPhoneOS*.sdk; do
  [ -d "$d" ] && { SDK="$d"; break; }
done

COMMON="-arch arm64 -miphoneos-version-min=13.0 $SRC -o $OUT -fobjc-arc -lobjc -framework Foundation"
if [ -n "$SDK" ]; then
  echo "sdk=$SDK"
  clang -isysroot "$SDK" $COMMON
else
  echo "sdk=none"
  clang $COMMON
fi

chmod 755 "$OUT"
if command -v ldid >/dev/null 2>&1; then
  ldid -S "$OUT" || true
fi

ls -lh "$OUT"
exit 0
