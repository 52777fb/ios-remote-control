#import <Foundation/Foundation.h>
#import <dispatch/dispatch.h>
#import <objc/runtime.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

static NSString *const kLogPath = @"/var/mobile/Library/Logs/sbnetprobe.log";

static void logLine(NSString *line) {
    @autoreleasepool {
        NSFileManager *fm = [NSFileManager defaultManager];
        [fm createDirectoryAtPath:[kLogPath stringByDeletingLastPathComponent]
      withIntermediateDirectories:YES attributes:nil error:nil];

        NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
        fmt.dateFormat = @"yyyy-MM-dd HH:mm:ss";
        NSString *ts = [fmt stringFromDate:[NSDate date]];
        NSString *out = [NSString stringWithFormat:@"%@ %@\n", ts, line];

        NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:kLogPath];
        if (!fh) {
            [out writeToFile:kLogPath atomically:YES encoding:NSUTF8StringEncoding error:nil];
            return;
        }
        [fh seekToEndOfFile];
        [fh writeData:[out dataUsingEncoding:NSUTF8StringEncoding]];
        [fh closeFile];
    }
}

static BOOL nameMatches(const char *name) {
    if (!name) return NO;
    const char *needles[] = {
        "WiFi", "Wifi", "wifi",
        "Cellular", "cellular",
        "Telephony", "telephony",
        "Radio", "radio",
        "DataUsage", "DataNetwork",
        "NetworkController",
        "Airplane",
        NULL
    };
    for (int i = 0; needles[i]; i++) {
        if (strstr(name, needles[i])) return YES;
    }
    return NO;
}

static void runProbe(void) {
    @autoreleasepool {
        logLine(@"sbnetprobe 0.1.0 started");
        int count = objc_getClassList(NULL, 0);
        logLine([NSString stringWithFormat:@"class_count=%d", count]);
        if (count <= 0) return;

        Class *classes = (Class *)calloc((size_t)count, sizeof(Class));
        if (!classes) {
            logLine(@"calloc failed");
            return;
        }

        int got = objc_getClassList(classes, count);
        int matched = 0;
        for (int i = 0; i < got; i++) {
            const char *name = class_getName(classes[i]);
            if (!nameMatches(name)) continue;
            matched++;
            logLine([NSString stringWithFormat:@"class=%s", name]);
        }
        free(classes);
        logLine([NSString stringWithFormat:@"matched=%d", matched]);
        logLine(@"safe_result=read_only_no_network_change");
    }
}

__attribute__((constructor))
static void ctor(void) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        runProbe();
    });
}
