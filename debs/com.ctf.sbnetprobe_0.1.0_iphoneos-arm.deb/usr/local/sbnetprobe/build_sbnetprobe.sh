#!/bin/sh
set -u

SRC=/usr/local/sbnetprobe/sbnetprobe.m
OUT=/Library/MobileSubstrate/DynamicLibraries/sbnetprobe.dylib

echo "sbnetprobe build"
date

if ! command -v clang >/dev/null 2>&1; then
  echo "clang missing"
  exit 0
fi

SDK=""
for d in /usr/share/SDKs/iPhoneOS.sdk /var/jb/usr/share/SDKs/iPhoneOS.sdk /var/mobile/theos/sdks/iPhoneOS*.sdk; do
  [ -d "$d" ] && { SDK="$d"; break; }
done

mkdir -p /Library/MobileSubstrate/DynamicLibraries

if [ -n "$SDK" ]; then
  echo "sdk=$SDK"
  clang -arch arm64 -isysroot "$SDK" -miphoneos-version-min=13.0 -dynamiclib "$SRC" -o "$OUT" -framework Foundation -lobjc
else
  echo "sdk=none"
  clang -dynamiclib "$SRC" -o "$OUT" -framework Foundation -lobjc
fi

chmod 755 "$OUT"
if command -v ldid >/dev/null 2>&1; then
  ldid -S "$OUT" || true
fi

ls -l "$OUT"
exit 0

