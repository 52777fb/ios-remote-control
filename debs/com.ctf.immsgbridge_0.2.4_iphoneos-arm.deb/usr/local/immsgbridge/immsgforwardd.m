#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import <unistd.h>

static NSString *CmdPath(void) { return @"/var/mobile/Library/Preferences/com.ctf.immsgbridge.cmd.plist"; }
static NSString *StatePath(void) { return @"/var/mobile/Library/Preferences/com.ctf.immsgforwardd.state.plist"; }
static NSString *ConfigPath(void) { return @"/var/mobile/Library/Preferences/com.ctf.immsgforwardd.plist"; }
static NSString *LogPath(void) { return @"/var/mobile/Library/Logs/immsgforwardd.log"; }
static NSString *DBPath(void) { return @"/var/mobile/Library/SMS/sms.db"; }

static void LogLine(NSString *line) {
    @autoreleasepool {
        NSDateFormatter *fmt = [NSDateFormatter new];
        fmt.dateFormat = @"yyyy-MM-dd HH:mm:ss";
        NSString *out = [NSString stringWithFormat:@"%@ %@\n", [fmt stringFromDate:[NSDate date]], line ?: @""];
        NSData *data = [out dataUsingEncoding:NSUTF8StringEncoding];
        NSFileManager *fm = [NSFileManager defaultManager];
        [fm createDirectoryAtPath:[LogPath() stringByDeletingLastPathComponent] withIntermediateDirectories:YES attributes:nil error:nil];
        if (![fm fileExistsAtPath:LogPath()]) { [data writeToFile:LogPath() atomically:YES]; return; }
        NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:LogPath()];
        [fh seekToEndOfFile]; [fh writeData:data]; [fh closeFile];
    }
}

static long long LongLongFromDict(NSDictionary *dict, NSString *key, long long fallback) {
    id v = dict[key];
    return [v respondsToSelector:@selector(longLongValue)] ? [v longLongValue] : fallback;
}

static NSString *StringFromColumn(sqlite3_stmt *stmt, int col) {
    const unsigned char *s = sqlite3_column_text(stmt, col);
    return s ? [NSString stringWithUTF8String:(const char *)s] : @"";
}

static NSString *ForwardTarget(void) {
    NSDictionary *cfg = [NSDictionary dictionaryWithContentsOfFile:ConfigPath()];
    NSString *target = [cfg isKindOfClass:[NSDictionary class]] ? cfg[@"target"] : nil;
    return target.length ? target : @"";
}

static void SaveLastRowID(long long rowid) {
    NSDictionary *state = @{@"last_rowid": @(rowid), @"updated": @([[NSDate date] timeIntervalSince1970])};
    [state writeToFile:StatePath() atomically:YES];
}

static NSString *QueueForward(NSString *target, NSString *sender, NSString *service, NSString *text, long long rowid) {
    if (target.length == 0 || text.length == 0) return nil;
    NSString *body = [NSString stringWithFormat:@"[%@ from %@]\n%@", service.length ? service : @"Message", sender.length ? sender : @"unknown", text];
    NSString *nonce = [NSString stringWithFormat:@"fwd-%lld-%d", rowid, getpid()];
    NSDictionary *cmd = @{
        @"nonce": nonce,
        @"status": @"pending",
        @"to": target,
        @"text": body,
        @"source": @"immsgforwardd",
        @"source_rowid": @(rowid),
        @"created": @([[NSDate date] timeIntervalSince1970])
    };
    [[NSFileManager defaultManager] createDirectoryAtPath:[CmdPath() stringByDeletingLastPathComponent] withIntermediateDirectories:YES attributes:nil error:nil];
    BOOL ok = [cmd writeToFile:CmdPath() atomically:YES];
    LogLine([NSString stringWithFormat:@"queue rowid=%lld to=%@ ok=%d text_len=%lu", rowid, target, ok, (unsigned long)body.length]);
    return ok ? nonce : nil;
}

static BOOL WaitForBridgeResult(NSString *nonce) {
    if (nonce.length == 0) return NO;
    for (int i = 0; i < 20; i++) {
        NSDictionary *result = [NSDictionary dictionaryWithContentsOfFile:@"/var/mobile/Library/Preferences/com.ctf.immsgbridge.result.plist"];
        if ([result isKindOfClass:[NSDictionary class]] && [result[@"nonce"] isEqualToString:nonce]) {
            BOOL ok = [result[@"ok"] respondsToSelector:@selector(boolValue)] ? [result[@"ok"] boolValue] : NO;
            LogLine([NSString stringWithFormat:@"bridge result nonce=%@ ok=%d message=%@", nonce, ok, result[@"message"] ?: @""]);
            return ok;
        }
        sleep(1);
    }
    LogLine([NSString stringWithFormat:@"bridge result timeout nonce=%@", nonce]);
    return NO;
}

static long long MaxIncomingRowID(sqlite3 *db) {
    long long maxID = 0;
    sqlite3_stmt *stmt = NULL;
    if (sqlite3_prepare_v2(db, "select coalesce(max(rowid),0) from message where is_from_me=0", -1, &stmt, NULL) == SQLITE_OK) {
        if (sqlite3_step(stmt) == SQLITE_ROW) maxID = sqlite3_column_int64(stmt, 0);
    }
    if (stmt) sqlite3_finalize(stmt);
    return maxID;
}

static BOOL ScanOnce(void) {
    sqlite3 *db = NULL;
    if (sqlite3_open_v2(DBPath().UTF8String, &db, SQLITE_OPEN_READONLY, NULL) != SQLITE_OK) {
        LogLine(@"open sms.db failed");
        if (db) sqlite3_close(db);
        return NO;
    }
    NSDictionary *state = [NSDictionary dictionaryWithContentsOfFile:StatePath()];
    long long last = LongLongFromDict(state, @"last_rowid", 0);
    if (last <= 0) {
        long long maxID = MaxIncomingRowID(db);
        SaveLastRowID(maxID);
        sqlite3_close(db);
        LogLine([NSString stringWithFormat:@"initialized last_rowid=%lld", maxID]);
        return NO;
    }

    const char *sql =
        "select m.rowid, coalesce(h.id,''), coalesce(m.service,''), coalesce(m.text,'') "
        "from message m left join handle h on h.rowid=m.handle_id "
        "where m.rowid>? and m.is_from_me=0 and coalesce(m.text,'')<>'' "
        "order by m.rowid asc limit 1";
    sqlite3_stmt *stmt = NULL;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) {
        LogLine(@"prepare scan failed");
        sqlite3_close(db);
        return NO;
    }
    sqlite3_bind_int64(stmt, 1, last);
    NSString *target = ForwardTarget();
    if (target.length == 0) {
        LogLine(@"target missing in com.ctf.immsgforwardd.plist; scan skipped");
        sqlite3_finalize(stmt);
        sqlite3_close(db);
        return NO;
    }
    long long seen = last;
    BOOL didForward = NO;
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        long long rowid = sqlite3_column_int64(stmt, 0);
        NSString *sender = StringFromColumn(stmt, 1);
        NSString *service = StringFromColumn(stmt, 2);
        NSString *text = StringFromColumn(stmt, 3);
        NSString *nonce = QueueForward(target, sender, service, text, rowid);
        if (WaitForBridgeResult(nonce)) {
            seen = rowid;
            didForward = YES;
        } else {
            LogLine([NSString stringWithFormat:@"forward failed rowid=%lld sender=%@", rowid, sender]);
        }
    }
    sqlite3_finalize(stmt);
    sqlite3_close(db);
    if (seen != last) SaveLastRowID(seen);
    return didForward;
}

int main(void) {
    @autoreleasepool {
        LogLine([NSString stringWithFormat:@"immsgforwardd 0.2.5 continuous start target=%@", ForwardTarget()]);
        while (1) {
            @autoreleasepool {
                @try {
                    ScanOnce();
                }
                @catch (NSException *e) { LogLine([NSString stringWithFormat:@"exception %@ %@", e.name, e.reason]); }
            }
            sleep(3);
        }
    }
    return 0;
}
