#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreGraphics/CoreGraphics.h>
#import <CoreVideo/CoreVideo.h>
#import <CoreMedia/CoreMedia.h>
#import <VideoToolbox/VideoToolbox.h>
#import <CommonCrypto/CommonDigest.h>
#import <libkern/OSByteOrder.h>
#import <arpa/inet.h>
#import <netinet/in.h>
#import <signal.h>
#import <sys/socket.h>
#import <unistd.h>

static const int kPort = 58588;
static volatile int gClient = -1;
static VTCompressionSessionRef gSession = NULL;
static int gWidth = 0;
static int gHeight = 0;
static int gFps = 30;
static uint64_t gFrame = 0;
static volatile int gStreaming = 0;
static uint64_t gCaptureCount = 0;

static void logLine(NSString *s) {
  NSString *line = [NSString stringWithFormat:@"%@ %@\n", [NSDate date], s];
  NSData *d = [line dataUsingEncoding:NSUTF8StringEncoding];
  NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:@"/var/mobile/Library/Logs/h264remote.log"];
  if (!fh) {
    [d writeToFile:@"/var/mobile/Library/Logs/h264remote.log" atomically:YES];
    return;
  }
  [fh seekToEndOfFile];
  [fh writeData:d];
  [fh closeFile];
}

static BOOL sendAll(int fd, const void *buf, size_t len) {
  const uint8_t *p = (const uint8_t *)buf;
  while (len > 0) {
    ssize_t n = send(fd, p, len, 0);
    if (n <= 0) return NO;
    p += n;
    len -= (size_t)n;
  }
  return YES;
}

static BOOL wsSendFrame(int fd, NSData *payload, uint8_t opcode) {
  uint8_t h[10];
  size_t hlen = 0;
  h[0] = 0x80 | (opcode & 0x0f);
  uint64_t len = payload.length;
  if (len < 126) {
    h[1] = (uint8_t)len;
    hlen = 2;
  } else if (len <= UINT16_MAX) {
    h[1] = 126;
    uint16_t v = htons((uint16_t)len);
    memcpy(h + 2, &v, 2);
    hlen = 4;
  } else {
    h[1] = 127;
    uint64_t v = OSSwapHostToBigInt64(len);
    memcpy(h + 2, &v, 8);
    hlen = 10;
  }
  return sendAll(fd, h, hlen) && sendAll(fd, payload.bytes, payload.length);
}

static NSString *base64SHA1(NSString *input) {
  NSData *data = [input dataUsingEncoding:NSUTF8StringEncoding];
  unsigned char digest[CC_SHA1_DIGEST_LENGTH];
  CC_SHA1(data.bytes, (CC_LONG)data.length, digest);
  NSData *digestData = [NSData dataWithBytes:digest length:CC_SHA1_DIGEST_LENGTH];
  return [digestData base64EncodedStringWithOptions:0];
}

static BOOL handshake(int client, NSString *request) {
  NSString *key = nil;
  for (NSString *line in [request componentsSeparatedByString:@"\r\n"]) {
    if ([[line lowercaseString] hasPrefix:@"sec-websocket-key:"]) {
      key = [[line substringFromIndex:[@"sec-websocket-key:" length]] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
      break;
    }
  }
  if (!key) return NO;
  NSString *accept = base64SHA1([key stringByAppendingString:@"258EAFA5-E914-47DA-95CA-C5AB0DC85B11"]);
  NSString *resp = [NSString stringWithFormat:@"HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: %@\r\n\r\n", accept];
  return sendAll(client, resp.UTF8String, strlen(resp.UTF8String));
}

static CVPixelBufferRef capturePixelBuffer(void) {
  __block CVPixelBufferRef pb = NULL;
  dispatch_sync(dispatch_get_main_queue(), ^{
    NSDictionary *attrs = @{
      (id)kCVPixelBufferCGImageCompatibilityKey: @YES,
      (id)kCVPixelBufferCGBitmapContextCompatibilityKey: @YES,
      (id)kCVPixelBufferIOSurfacePropertiesKey: @{}
    };
    CVReturn rc = CVPixelBufferCreate(kCFAllocatorDefault, gWidth, gHeight, kCVPixelFormatType_32BGRA, (__bridge CFDictionaryRef)attrs, &pb);
    if (rc != kCVReturnSuccess || !pb) return;
    CVPixelBufferLockBaseAddress(pb, 0);
    void *base = CVPixelBufferGetBaseAddress(pb);
    size_t bytesPerRow = CVPixelBufferGetBytesPerRow(pb);
    CGColorSpaceRef cs = CGColorSpaceCreateDeviceRGB();
    CGContextRef ctx = CGBitmapContextCreate(base, gWidth, gHeight, 8, bytesPerRow, cs, kCGBitmapByteOrder32Little | kCGImageAlphaPremultipliedFirst);
    if (ctx) {
      CGContextSetRGBFillColor(ctx, 0, 0, 0, 1);
      CGContextFillRect(ctx, CGRectMake(0, 0, gWidth, gHeight));
      NSArray *windows = [[UIApplication sharedApplication].windows sortedArrayUsingComparator:^NSComparisonResult(UIWindow *a, UIWindow *b) {
        if (a.windowLevel < b.windowLevel) return NSOrderedAscending;
        if (a.windowLevel > b.windowLevel) return NSOrderedDescending;
        return NSOrderedSame;
      }];
      UIGraphicsPushContext(ctx);
      CGFloat scale = [UIScreen mainScreen].scale;
      CGContextScaleCTM(ctx, scale, scale);
      int drawn = 0;
      for (UIWindow *window in windows) {
        if (window.hidden || window.alpha <= 0.01) continue;
        CGRect bounds = window.bounds;
        if (CGRectIsEmpty(bounds) || CGRectGetWidth(bounds) < 1 || CGRectGetHeight(bounds) < 1) continue;
        @try {
          [window drawViewHierarchyInRect:bounds afterScreenUpdates:NO];
          drawn++;
        } @catch (NSException *ex) {
          logLine([NSString stringWithFormat:@"window draw exception %@", ex.name]);
        }
      }
      UIGraphicsPopContext();
      gCaptureCount++;
      if (gCaptureCount == 1 || gCaptureCount % 300 == 0) {
        logLine([NSString stringWithFormat:@"capture windows=%lu drawn=%d", (unsigned long)windows.count, drawn]);
      }
      CGContextRelease(ctx);
    }
    CGColorSpaceRelease(cs);
    CVPixelBufferUnlockBaseAddress(pb, 0);
  });
  return pb;
}

static void appendStartCode(NSMutableData *out) {
  static const uint8_t sc[] = {0, 0, 0, 1};
  [out appendBytes:sc length:4];
}

static void sendSampleBuffer(CMSampleBufferRef sb) {
  int fd = gClient;
  if (fd < 0 || !sb) return;

  NSMutableData *out = [NSMutableData data];
  CFArrayRef attachments = CMSampleBufferGetSampleAttachmentsArray(sb, false);
  BOOL keyframe = YES;
  if (attachments && CFArrayGetCount(attachments)) {
    CFDictionaryRef att = (CFDictionaryRef)CFArrayGetValueAtIndex(attachments, 0);
    keyframe = !CFDictionaryContainsKey(att, kCMSampleAttachmentKey_NotSync);
  }

  if (keyframe) {
    CMFormatDescriptionRef fmt = CMSampleBufferGetFormatDescription(sb);
    const uint8_t *sps = NULL, *pps = NULL;
    size_t spsSize = 0, ppsSize = 0, count = 0;
    if (CMVideoFormatDescriptionGetH264ParameterSetAtIndex(fmt, 0, &sps, &spsSize, &count, NULL) == noErr &&
        CMVideoFormatDescriptionGetH264ParameterSetAtIndex(fmt, 1, &pps, &ppsSize, &count, NULL) == noErr) {
      appendStartCode(out);
      [out appendBytes:sps length:spsSize];
      appendStartCode(out);
      [out appendBytes:pps length:ppsSize];
    }
  }

  CMBlockBufferRef bb = CMSampleBufferGetDataBuffer(sb);
  size_t total = 0;
  char *data = NULL;
  if (CMBlockBufferGetDataPointer(bb, 0, NULL, &total, &data) != kCMBlockBufferNoErr) return;
  size_t off = 0;
  while (off + 4 <= total) {
    uint32_t naluLen = 0;
    memcpy(&naluLen, data + off, 4);
    naluLen = OSSwapBigToHostInt32(naluLen);
    off += 4;
    if (off + naluLen > total) break;
    appendStartCode(out);
    [out appendBytes:data + off length:naluLen];
    off += naluLen;
  }

  if (out.length && !wsSendFrame(fd, out, 0x2)) {
    logLine(@"send failed; closing client");
    gClient = -1;
    close(fd);
  }
}

static void encodeCallback(void *outputCallbackRefCon, void *sourceFrameRefCon, OSStatus status, VTEncodeInfoFlags infoFlags, CMSampleBufferRef sampleBuffer) {
  if (status != noErr || !CMSampleBufferDataIsReady(sampleBuffer)) return;
  sendSampleBuffer(sampleBuffer);
}

static BOOL setupEncoder(void) {
  if (gSession) {
    VTCompressionSessionInvalidate(gSession);
    CFRelease(gSession);
    gSession = NULL;
  }
  OSStatus st = VTCompressionSessionCreate(kCFAllocatorDefault, gWidth, gHeight, kCMVideoCodecType_H264, NULL, NULL, NULL, encodeCallback, NULL, &gSession);
  if (st != noErr || !gSession) {
    logLine([NSString stringWithFormat:@"VTCompressionSessionCreate failed %d", (int)st]);
    return NO;
  }
  VTSessionSetProperty(gSession, kVTCompressionPropertyKey_RealTime, kCFBooleanTrue);
  VTSessionSetProperty(gSession, kVTCompressionPropertyKey_AllowFrameReordering, kCFBooleanFalse);
  VTSessionSetProperty(gSession, kVTCompressionPropertyKey_ProfileLevel, kVTProfileLevel_H264_Baseline_AutoLevel);
  int32_t fps = gFps;
  int32_t bitRate = 2500000;
  int32_t keyInt = gFps;
  CFNumberRef nFps = CFNumberCreate(NULL, kCFNumberSInt32Type, &fps);
  CFNumberRef nBr = CFNumberCreate(NULL, kCFNumberSInt32Type, &bitRate);
  CFNumberRef nKey = CFNumberCreate(NULL, kCFNumberSInt32Type, &keyInt);
  VTSessionSetProperty(gSession, kVTCompressionPropertyKey_ExpectedFrameRate, nFps);
  VTSessionSetProperty(gSession, kVTCompressionPropertyKey_AverageBitRate, nBr);
  VTSessionSetProperty(gSession, kVTCompressionPropertyKey_MaxKeyFrameInterval, nKey);
  CFRelease(nFps);
  CFRelease(nBr);
  CFRelease(nKey);
  VTCompressionSessionPrepareToEncodeFrames(gSession);
  return YES;
}

static void streamLoop(void) {
  if (__sync_lock_test_and_set(&gStreaming, 1)) {
    logLine(@"stream rejected; already running");
    return;
  }
  if (!setupEncoder()) {
    __sync_lock_release(&gStreaming);
    return;
  }
  logLine([NSString stringWithFormat:@"stream start %dx%d fps=%d", gWidth, gHeight, gFps]);
  while (gClient >= 0) {
    @autoreleasepool {
      NSTimeInterval start = [NSDate timeIntervalSinceReferenceDate];
      CVPixelBufferRef pb = capturePixelBuffer();
      if (pb) {
        CMTime pts = CMTimeMake((int64_t)gFrame++, gFps);
        VTEncodeInfoFlags flags = 0;
        VTCompressionSessionEncodeFrame(gSession, pb, pts, kCMTimeInvalid, NULL, NULL, &flags);
        CVPixelBufferRelease(pb);
      }
      VTCompressionSessionCompleteFrames(gSession, kCMTimeInvalid);
      NSTimeInterval elapsed = [NSDate timeIntervalSinceReferenceDate] - start;
      NSTimeInterval wait = MAX(0.0, (1.0 / gFps) - elapsed);
      [NSThread sleepForTimeInterval:wait];
    }
  }
  if (gSession) {
    VTCompressionSessionCompleteFrames(gSession, kCMTimeInvalid);
    VTCompressionSessionInvalidate(gSession);
    CFRelease(gSession);
    gSession = NULL;
  }
  __sync_lock_release(&gStreaming);
  logLine(@"stream end");
}

@interface H264RemoteServer : NSObject
@end

@implementation H264RemoteServer
- (void)start {
  CGRect b = [UIScreen mainScreen].bounds;
  CGFloat scale = [UIScreen mainScreen].scale;
  gWidth = (int)CGRectGetWidth(b) * (int)scale;
  gHeight = (int)CGRectGetHeight(b) * (int)scale;
  [NSThread detachNewThreadSelector:@selector(serverThread) toTarget:self withObject:nil];
  logLine([NSString stringWithFormat:@"h264remote ctor port=%d size=%dx%d", kPort, gWidth, gHeight]);
}
- (void)serverThread {
  @autoreleasepool {
    int server = socket(AF_INET, SOCK_STREAM, 0);
    int yes = 1;
    setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons((uint16_t)kPort);
    if (bind(server, (struct sockaddr *)&addr, sizeof(addr)) != 0 || listen(server, 4) != 0) {
      logLine(@"listen failed");
      close(server);
      return;
    }
    while (1) {
      int client = accept(server, NULL, NULL);
      if (client < 0) continue;
      char buf[4096] = {0};
      recv(client, buf, sizeof(buf) - 1, 0);
      NSString *req = [NSString stringWithUTF8String:buf] ?: @"";
      if (!handshake(client, req)) {
        close(client);
        continue;
      }
      int one = 1;
#ifdef SO_NOSIGPIPE
      setsockopt(client, SOL_SOCKET, SO_NOSIGPIPE, &one, sizeof(one));
#endif
      if (gClient >= 0) close(gClient);
      gClient = client;
      [NSThread detachNewThreadWithBlock:^{ streamLoop(); }];
    }
  }
}
@end

__attribute__((constructor))
static void h264remote_ctor(void) {
  @autoreleasepool {
    signal(SIGPIPE, SIG_IGN);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
      [[[H264RemoteServer alloc] init] start];
    });
  }
}
