#!/bin/sh
set -u

SRC=/usr/local/sbnetprobe/sbnetprobe.m
OUT=/Library/MobileSubstrate/DynamicLibraries/sbnetprobe.dylib
CTL_SRC=/usr/local/sbnetprobe/sbnetctl.c
CTL_OUT=/usr/bin/sbnetctl

echo "sbnetprobe build"
date
echo "version=0.1.5"

if ! command -v clang >/dev/null 2>&1; then
  echo "clang missing"
  exit 0
fi

SDK=""
for d in /usr/share/SDKs/iPhoneOS.sdk /var/jb/usr/share/SDKs/iPhoneOS.sdk /var/mobile/theos/sdks/iPhoneOS*.sdk; do
  [ -d "$d" ] && { SDK="$d"; break; }
done

mkdir -p /Library/MobileSubstrate/DynamicLibraries
mkdir -p /usr/bin

if [ -n "$SDK" ]; then
  echo "sdk=$SDK"
  clang -arch arm64 -isysroot "$SDK" -miphoneos-version-min=13.0 -dynamiclib "$SRC" -o "$OUT" -lobjc -lpthread
  clang -arch arm64 -isysroot "$SDK" -miphoneos-version-min=13.0 "$CTL_SRC" -o "$CTL_OUT"
else
  echo "sdk=none"
  clang -dynamiclib "$SRC" -o "$OUT" -lobjc -lpthread
  clang "$CTL_SRC" -o "$CTL_OUT"
fi

chmod 755 "$OUT"
chmod 755 "$CTL_OUT"
if command -v ldid >/dev/null 2>&1; then
  ldid -S "$OUT" || true
  ldid -S "$CTL_OUT" || true
fi

ls -l "$OUT"
ls -l "$CTL_OUT"
exit 0
