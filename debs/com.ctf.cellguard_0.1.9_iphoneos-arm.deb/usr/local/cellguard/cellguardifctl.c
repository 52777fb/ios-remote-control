#include <errno.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <unistd.h>

#if defined(__APPLE__)
#include <net/if_dl.h>
#endif

static int starts_with(const char *s, const char *p) {
    return s && p && strncmp(s, p, strlen(p)) == 0;
}

static void print_flags(unsigned int f) {
    printf(" flags=0x%x", f);
    if (f & IFF_UP) printf(" UP");
    if (f & IFF_RUNNING) printf(" RUNNING");
    if (f & IFF_LOOPBACK) printf(" LOOPBACK");
    if (f & IFF_POINTOPOINT) printf(" POINTOPOINT");
    if (f & IFF_BROADCAST) printf(" BROADCAST");
    if (f & IFF_MULTICAST) printf(" MULTICAST");
}

static int ioctl_get_flags(int s, const char *name, short *out) {
    struct ifreq ifr;
    memset(&ifr, 0, sizeof(ifr));
    snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", name);
    if (ioctl(s, SIOCGIFFLAGS, &ifr) != 0) return -1;
    *out = ifr.ifr_flags;
    return 0;
}

static int probe(void) {
    printf("cellguardifctl 0.1.9\n");
    printf("mode=read-only-control-probe\n");

    int s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0) {
        printf("control_socket=fail errno=%d %s\n", errno, strerror(errno));
        return 1;
    }
    printf("control_socket=ok\n");

    struct ifaddrs *ifap = NULL;
    if (getifaddrs(&ifap) != 0) {
        printf("getifaddrs=fail errno=%d %s\n", errno, strerror(errno));
        close(s);
        return 1;
    }

    int pdp = 0, wifi = 0;
    for (struct ifaddrs *ifa = ifap; ifa; ifa = ifa->ifa_next) {
        if (!ifa->ifa_name) continue;
        const char *name = ifa->ifa_name;
        if (!starts_with(name, "pdp_ip") && strcmp(name, "en0") != 0) continue;

        short fl = 0;
        int ok = ioctl_get_flags(s, name, &fl);
        if (starts_with(name, "pdp_ip")) pdp++;
        if (strcmp(name, "en0") == 0) wifi++;
        printf("%s", name);
        if (ok == 0) {
            print_flags((unsigned int)fl);
            printf(" ioctl_get=ok");
        } else {
            printf(" ioctl_get=fail errno=%d %s", errno, strerror(errno));
        }
#if defined(__APPLE__)
        if (ifa->ifa_data) {
            const struct if_data *d = (const struct if_data *)ifa->ifa_data;
            printf(" in=%llu out=%llu",
                   (unsigned long long)d->ifi_ibytes,
                   (unsigned long long)d->ifi_obytes);
        }
#endif
        printf("\n");
    }

    freeifaddrs(ifap);
    close(s);
    printf("pdp_candidates=%d\n", pdp);
    printf("wifi_en0_entries=%d\n", wifi);
    printf("safe_result=no_network_change\n");
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 2 || strcmp(argv[1], "probe") == 0) {
        return probe();
    }
    fprintf(stderr, "usage: cellguardifctl probe\n");
    return 2;
}

