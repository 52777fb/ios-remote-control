#import <Foundation/Foundation.h>
#import <objc/message.h>
#import <objc/runtime.h>
#import <dlfcn.h>

static NSString *LogPath(void) {
    return @"/var/mobile/Library/Logs/immsgsend.log";
}

static void LogLine(NSString *line) {
    @autoreleasepool {
        NSDateFormatter *fmt = [NSDateFormatter new];
        fmt.dateFormat = @"yyyy-MM-dd HH:mm:ss";
        NSString *out = [NSString stringWithFormat:@"%@ %@\n", [fmt stringFromDate:[NSDate date]], line];
        NSData *data = [out dataUsingEncoding:NSUTF8StringEncoding];
        NSFileManager *fm = [NSFileManager defaultManager];
        [fm createDirectoryAtPath:[LogPath() stringByDeletingLastPathComponent] withIntermediateDirectories:YES attributes:nil error:nil];
        if (![fm fileExistsAtPath:LogPath()]) {
            [data writeToFile:LogPath() atomically:YES];
            return;
        }
        NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:LogPath()];
        [fh seekToEndOfFile];
        [fh writeData:data];
        [fh closeFile];
    }
}

static NSString *ArgString(char *arg) {
    NSString *s = [[NSString alloc] initWithBytes:arg length:strlen(arg) encoding:NSUTF8StringEncoding];
    return s ?: [NSString stringWithUTF8String:arg] ?: @"";
}

static NSString *JoinText(int argc, char **argv) {
    NSMutableArray *parts = [NSMutableArray array];
    for (int i = 2; i < argc; i++) [parts addObject:ArgString(argv[i])];
    return [parts componentsJoinedByString:@" "];
}

static id ClassCall0(Class cls, NSString *selName) {
    SEL sel = NSSelectorFromString(selName);
    if (!cls || ![cls respondsToSelector:sel]) return nil;
    return ((id (*)(id, SEL))objc_msgSend)((id)cls, sel);
}

static id ObjCall0(id obj, NSString *selName) {
    SEL sel = NSSelectorFromString(selName);
    if (!obj || ![obj respondsToSelector:sel]) return nil;
    return ((id (*)(id, SEL))objc_msgSend)(obj, sel);
}

static id ObjCall1(id obj, NSString *selName, id a) {
    SEL sel = NSSelectorFromString(selName);
    if (!obj || ![obj respondsToSelector:sel]) return nil;
    return ((id (*)(id, SEL, id))objc_msgSend)(obj, sel, a);
}

static id ObjCall2(id obj, NSString *selName, id a, BOOL b) {
    SEL sel = NSSelectorFromString(selName);
    if (!obj || ![obj respondsToSelector:sel]) return nil;
    return ((id (*)(id, SEL, id, BOOL))objc_msgSend)(obj, sel, a, b);
}

static id ObjCall6(id obj, NSString *selName, id a, id b, id c, id d, BOOL e, BOOL f) {
    SEL sel = NSSelectorFromString(selName);
    if (!obj || ![obj respondsToSelector:sel]) return nil;
    return ((id (*)(id, SEL, id, id, id, id, BOOL, BOOL))objc_msgSend)(obj, sel, a, b, c, d, e, f);
}

static void ObjVoid0(id obj, NSString *selName) {
    SEL sel = NSSelectorFromString(selName);
    if (obj && [obj respondsToSelector:sel]) ((void (*)(id, SEL))objc_msgSend)(obj, sel);
}

static void ObjVoid1(id obj, NSString *selName, id a) {
    SEL sel = NSSelectorFromString(selName);
    if (obj && [obj respondsToSelector:sel]) ((void (*)(id, SEL, id))objc_msgSend)(obj, sel, a);
}

static NSString *SafeDesc(id obj) {
    if (!obj) return @"nil";
    @try {
        return [obj description] ?: @"<no description>";
    } @catch (__unused NSException *e) {
        return [NSString stringWithFormat:@"<%@ %p>", NSStringFromClass([obj class]), obj];
    }
}

static NSString *FirstStringGetter(id obj, NSArray<NSString *> *selectors) {
    for (NSString *name in selectors) {
        @try {
            id v = ObjCall0(obj, name);
            if ([v isKindOfClass:[NSString class]] && [(NSString *)v length] > 0) return v;
            if (v) LogLine([NSString stringWithFormat:@"getter %@ returned %@", name, SafeDesc(v)]);
        } @catch (NSException *e) {
            LogLine([NSString stringWithFormat:@"getter %@ exception %@ %@", name, e.name, e.reason]);
        }
    }
    return nil;
}

static BOOL ObjectLooksIMessage(id obj) {
    if (!obj) return NO;
    NSMutableArray<NSString *> *parts = [NSMutableArray array];
    NSString *desc = SafeDesc(obj);
    if (desc) [parts addObject:desc];
    NSString *s = FirstStringGetter(obj, @[
        @"internalName", @"serviceName", @"name", @"displayName", @"identifier",
        @"accountID", @"loginID", @"login", @"registrationServiceName"
    ]);
    if (s) [parts addObject:s];
    NSString *joined = [[parts componentsJoinedByString:@" "] lowercaseString];
    return [joined containsString:@"imessage"];
}

static void LogArrayCandidate(NSString *name, id value) {
    if (!value) {
        LogLine([NSString stringWithFormat:@"account_probe %@ => nil", name]);
        return;
    }
    LogLine([NSString stringWithFormat:@"account_probe %@ => %@ %@", name, NSStringFromClass([value class]), SafeDesc(value)]);
    if ([value isKindOfClass:[NSArray class]]) {
        NSArray *arr = (NSArray *)value;
        LogLine([NSString stringWithFormat:@"account_probe %@ count=%lu", name, (unsigned long)arr.count]);
        NSUInteger limit = MIN((NSUInteger)10, arr.count);
        for (NSUInteger i = 0; i < limit; i++) {
            id item = arr[i];
            LogLine([NSString stringWithFormat:@"account_probe %@[%lu] %@ %@", name, (unsigned long)i, NSStringFromClass([item class]), SafeDesc(item)]);
        }
    }
}

static BOOL ObjVoid3(id obj, NSString *selName, id a, id b, BOOL c) {
    SEL sel = NSSelectorFromString(selName);
    if (!obj || ![obj respondsToSelector:sel]) return NO;
    ((void (*)(id, SEL, id, id, BOOL))objc_msgSend)(obj, sel, a, b, c);
    return YES;
}

static BOOL ObjVoid2(id obj, NSString *selName, id a, id b) {
    SEL sel = NSSelectorFromString(selName);
    if (!obj || ![obj respondsToSelector:sel]) return NO;
    ((void (*)(id, SEL, id, id))objc_msgSend)(obj, sel, a, b);
    return YES;
}

static id MakeSingleton(NSString *className) {
    Class cls = NSClassFromString(className);
    NSArray *sels = @[@"sharedInstance", @"sharedRegistry", @"sharedController", @"defaultController", @"defaultRegistry"];
    for (NSString *s in sels) {
        id v = ClassCall0(cls, s);
        if (v) {
            LogLine([NSString stringWithFormat:@"%@ %@", className, s]);
            return v;
        }
    }
    return nil;
}

static void LoadIMFrameworks(void) {
    NSArray *paths = @[
        @"/System/Library/PrivateFrameworks/IMFoundation.framework/IMFoundation",
        @"/System/Library/PrivateFrameworks/IMCore.framework/IMCore",
        @"/System/Library/PrivateFrameworks/ChatKit.framework/ChatKit"
    ];
    for (NSString *p in paths) {
        void *h = dlopen(p.UTF8String, RTLD_NOW);
        LogLine([NSString stringWithFormat:@"dlopen %@ %@", p.lastPathComponent, h ? @"ok" : @"fail"]);
    }
}

static BOOL EnsureIMessageAccount(void) {
    id ac = MakeSingleton(@"IMAccountController");
    if (!ac) {
        LogLine(@"IMAccountController singleton missing");
        return NO;
    }
    id account = nil;
    @try {
        account = ObjCall0(ac, @"activeIMessageAccount");
    } @catch (NSException *e) {
        LogLine([NSString stringWithFormat:@"activeIMessageAccount exception %@ %@", e.name, e.reason]);
    }
    if (!account) {
        @try {
            account = ObjCall0(ac, @"mostLoggedInAccount");
            LogLine([NSString stringWithFormat:@"mostLoggedInAccount=%@", account ? @"yes" : @"no"]);
        } @catch (NSException *e) {
            LogLine([NSString stringWithFormat:@"mostLoggedInAccount exception %@ %@", e.name, e.reason]);
        }
    }
    LogLine([NSString stringWithFormat:@"active_iMessage_account=%@", account ? @"yes" : @"no"]);
    return account != nil;
}

static id CurrentIMessageAccount(void) {
    id ac = MakeSingleton(@"IMAccountController");
    if (!ac) return nil;
    id account = nil;
    @try {
        account = ObjCall0(ac, @"activeIMessageAccount");
    } @catch (NSException *e) {
        LogLine([NSString stringWithFormat:@"activeIMessageAccount exception %@ %@", e.name, e.reason]);
    }
    if (!account) {
        @try {
            account = ObjCall0(ac, @"mostLoggedInAccount");
        } @catch (NSException *e) {
            LogLine([NSString stringWithFormat:@"mostLoggedInAccount exception %@ %@", e.name, e.reason]);
        }
    }
    if (account && ObjectLooksIMessage(account)) return account;

    NSArray *arrayGetters = @[
        @"accounts", @"activeAccounts", @"operationalAccounts",
        @"connectedAccounts", @"loggedInAccounts", @"allAccounts"
    ];
    for (NSString *getter in arrayGetters) {
        @try {
            id value = ObjCall0(ac, getter);
            LogArrayCandidate(getter, value);
            if ([value isKindOfClass:[NSArray class]]) {
                for (id item in (NSArray *)value) {
                    if (ObjectLooksIMessage(item)) {
                        LogLine([NSString stringWithFormat:@"selected_iMessage_account via %@", getter]);
                        return item;
                    }
                }
            } else if (ObjectLooksIMessage(value)) {
                LogLine([NSString stringWithFormat:@"selected_iMessage_account via %@", getter]);
                return value;
            }
        } @catch (NSException *e) {
            LogLine([NSString stringWithFormat:@"account getter %@ exception %@ %@", getter, e.name, e.reason]);
        }
    }
    return account;
}

static id MakeHandle(NSString *recipient) {
    id account = CurrentIMessageAccount();
    Class handleCls = NSClassFromString(@"IMHandle");
    if (!handleCls) {
        LogLine(@"IMHandle missing");
        return nil;
    }

    NSArray *classTries = @[
        @"existingIMHandleWithID:",
        @"existingIMHandleWithID:alreadyCanonical:",
        @"existingIMHandleWithID:countryCode:"
    ];
    for (NSString *name in classTries) {
        @try {
            SEL sel = NSSelectorFromString(name);
            if (![handleCls respondsToSelector:sel]) continue;
            id h = nil;
            if ([name isEqualToString:@"existingIMHandleWithID:"]) {
                h = ((id (*)(id, SEL, id))objc_msgSend)((id)handleCls, sel, recipient);
            } else if ([name isEqualToString:@"existingIMHandleWithID:alreadyCanonical:"]) {
                h = ((id (*)(id, SEL, id, BOOL))objc_msgSend)((id)handleCls, sel, recipient, NO);
            } else {
                h = ((id (*)(id, SEL, id, id))objc_msgSend)((id)handleCls, sel, recipient, nil);
            }
            if (h) {
                LogLine([NSString stringWithFormat:@"handle via class %@", name]);
                return h;
            }
        } @catch (NSException *e) {
            LogLine([NSString stringWithFormat:@"handle class %@ exception %@ %@", name, e.name, e.reason]);
        }
    }

    NSArray *initTries = @[
        @"initWithAccount:ID:alreadyCanonical:",
        @"initWithAccount:ID:",
        @"initWithID:account:",
        @"initWithID:alreadyCanonical:",
        @"initWithID:"
    ];
    for (NSString *name in initTries) {
        @try {
            id obj = ((id (*)(id, SEL))objc_msgSend)((id)handleCls, NSSelectorFromString(@"alloc"));
            SEL sel = NSSelectorFromString(name);
            if (![obj respondsToSelector:sel]) continue;
            id h = nil;
            if ([name isEqualToString:@"initWithAccount:ID:alreadyCanonical:"]) {
                h = ((id (*)(id, SEL, id, id, BOOL))objc_msgSend)(obj, sel, account, recipient, NO);
            } else if ([name isEqualToString:@"initWithAccount:ID:"]) {
                h = ((id (*)(id, SEL, id, id))objc_msgSend)(obj, sel, account, recipient);
            } else if ([name isEqualToString:@"initWithID:account:"]) {
                h = ((id (*)(id, SEL, id, id))objc_msgSend)(obj, sel, recipient, account);
            } else if ([name isEqualToString:@"initWithID:alreadyCanonical:"]) {
                h = ((id (*)(id, SEL, id, BOOL))objc_msgSend)(obj, sel, recipient, NO);
            } else {
                h = ((id (*)(id, SEL, id))objc_msgSend)(obj, sel, recipient);
            }
            if (h) {
                LogLine([NSString stringWithFormat:@"handle via %@", name]);
                return h;
            }
        } @catch (NSException *e) {
            LogLine([NSString stringWithFormat:@"handle init %@ exception %@ %@", name, e.name, e.reason]);
        }
    }

    LogLine(@"handle_create_failed");
    return nil;
}

static BOOL ChatLooksIMessageOnly(id chat) {
    if (!chat) return NO;
    LogLine([NSString stringWithFormat:@"chat=%@", SafeDesc(chat)]);

    id service = nil;
    NSArray *serviceSelectors = @[@"__ck_service", @"service", @"_service"];
    for (NSString *sel in serviceSelectors) {
        @try {
            service = ObjCall0(chat, sel);
            if (service) {
                LogLine([NSString stringWithFormat:@"chat_service via %@ => %@", sel, SafeDesc(service)]);
                break;
            }
        } @catch (NSException *e) {
            LogLine([NSString stringWithFormat:@"chat_service %@ exception %@ %@", sel, e.name, e.reason]);
        }
    }

    NSMutableArray<NSString *> *needles = [NSMutableArray array];
    NSString *chatService = FirstStringGetter(chat, @[@"serviceName", @"service", @"__ck_service", @"accountID", @"guid", @"chatIdentifier"]);
    if (chatService) [needles addObject:chatService];
    NSString *serviceName = FirstStringGetter(service, @[@"internalName", @"name", @"serviceName", @"displayName", @"identifier"]);
    if (serviceName) [needles addObject:serviceName];

    NSString *joined = [[needles componentsJoinedByString:@" "] lowercaseString];
    LogLine([NSString stringWithFormat:@"service_probe='%@'", joined]);
    if ([joined containsString:@"imessage"]) {
        LogLine(@"service_confirmed_iMessage");
        return YES;
    }

    LogLine(@"service_not_confirmed_iMessage_abort_no_sms");
    return NO;
}

static id MakeChat(NSString *recipient) {
    id registry = MakeSingleton(@"IMChatRegistry");
    if (!registry) {
        LogLine(@"IMChatRegistry singleton missing");
        return nil;
    }

    id handle = MakeHandle(recipient);
    if (!handle) return nil;
    LogLine([NSString stringWithFormat:@"handle=%@", SafeDesc(handle)]);
    NSArray *handles = @[handle];
    id chat = nil;

    @try {
        chat = ObjCall2(registry, @"_ck_chatForHandles:createIfNecessary:", handles, YES);
        if (chat) {
            LogLine(@"chat created via _ck_chatForHandles:createIfNecessary:");
            return chat;
        }
    } @catch (NSException *e) {
        LogLine([NSString stringWithFormat:@"chat try1 exception %@ %@", e.name, e.reason]);
    }

    @try {
        chat = ObjCall6(registry, @"_ck_chatForHandles:displayName:lastAddressedHandle:lastAddressedSIMID:joinedChatsOnly:createIfNecessary:", handles, nil, handle, nil, NO, YES);
        if (chat) {
            LogLine(@"chat created via extended _ck_chatForHandles");
            return chat;
        }
    } @catch (NSException *e) {
        LogLine([NSString stringWithFormat:@"chat try2 exception %@ %@", e.name, e.reason]);
    }

    LogLine(@"chat_create_failed");
    return nil;
}

static id MakeMessage(NSString *text) {
    Class msgCls = NSClassFromString(@"IMMessage");
    if (!msgCls) {
        LogLine(@"IMMessage missing");
        return nil;
    }

    @try {
        SEL sel = NSSelectorFromString(@"instantMessageWithText:flags:threadIdentifier:");
        if ([msgCls respondsToSelector:sel]) {
            id msg = ((id (*)(id, SEL, id, unsigned int, id))objc_msgSend)((id)msgCls, sel, text, 0u, nil);
            if (msg) {
                LogLine(@"message via instantMessageWithText:flags:threadIdentifier:");
                return msg;
            }
        }
    } @catch (NSException *e) {
        LogLine([NSString stringWithFormat:@"message try1 exception %@ %@", e.name, e.reason]);
    }

    @try {
        SEL sel = NSSelectorFromString(@"instantMessageWithText:messageSubject:flags:threadIdentifier:");
        if ([msgCls respondsToSelector:sel]) {
            id msg = ((id (*)(id, SEL, id, id, unsigned int, id))objc_msgSend)((id)msgCls, sel, text, nil, 0u, nil);
            if (msg) {
                LogLine(@"message via instantMessageWithText:messageSubject:flags:threadIdentifier:");
                return msg;
            }
        }
    } @catch (NSException *e) {
        LogLine([NSString stringWithFormat:@"message try2 exception %@ %@", e.name, e.reason]);
    }

    LogLine(@"message_create_failed");
    return nil;
}

static BOOL SendMessage(id chat, id msg) {
    @try {
        if (ObjVoid3(chat, @"_sendMessage:adjustingSender:shouldQueue:", msg, nil, YES)) {
            LogLine(@"send via IMChat _sendMessage:adjustingSender:shouldQueue:");
            return YES;
        }
    } @catch (NSException *e) {
        LogLine([NSString stringWithFormat:@"send try1 exception %@ %@", e.name, e.reason]);
    }

    @try {
        id registry = MakeSingleton(@"IMChatRegistry");
        if (ObjVoid2(registry, @"_chat:sendMessage:", chat, msg)) {
            LogLine(@"send via IMChatRegistry _chat:sendMessage:");
            return YES;
        }
    } @catch (NSException *e) {
        LogLine([NSString stringWithFormat:@"send try2 exception %@ %@", e.name, e.reason]);
    }

    LogLine(@"send_failed_no_sms_fallback");
    return NO;
}

int main(int argc, char **argv) {
    @autoreleasepool {
        if (argc < 3) {
            fprintf(stderr, "usage: immsgsend <iMessage-recipient-phone-or-appleid> <text>\n");
            fprintf(stderr, "SMS fallback is disabled.\n");
            return 2;
        }

        NSString *to = ArgString(argv[1]);
        NSString *text = JoinText(argc, argv);
        LogLine([NSString stringWithFormat:@"immsgsend 0.2.4 start to=%@ text_len=%lu sms_fallback=disabled", to, (unsigned long)text.length]);

        LoadIMFrameworks();

        id daemon = MakeSingleton(@"IMDaemonController");
        if (daemon) {
            ObjVoid0(daemon, @"connectToDaemon");
            ObjVoid0(daemon, @"blockUntilConnected");
            ObjVoid1(daemon, @"addListenerID:", @"com.ctf.immsgsend");
            LogLine(@"daemon_connect_attempted");
        } else {
            LogLine(@"daemon_missing_continue");
        }

        if (!EnsureIMessageAccount()) {
            LogLine(@"account_probe_empty_continue_to_chat_service_check");
        }

        id chat = MakeChat(to);
        if (!chat) {
            fprintf(stderr, "cannot create iMessage chat; refusing SMS fallback\n");
            return 1;
        }
        if (!ChatLooksIMessageOnly(chat)) {
            fprintf(stderr, "chat is not confirmed iMessage; refusing SMS fallback\n");
            return 1;
        }

        id msg = MakeMessage(text);
        if (!msg) {
            fprintf(stderr, "cannot create IMMessage; refusing SMS fallback\n");
            return 1;
        }

        if (!SendMessage(chat, msg)) {
            fprintf(stderr, "iMessage send failed; SMS fallback disabled\n");
            return 1;
        }

        printf("iMessage send attempted; SMS fallback disabled\n");
        return 0;
    }
}
