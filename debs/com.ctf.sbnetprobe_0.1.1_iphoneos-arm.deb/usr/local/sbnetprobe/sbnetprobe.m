#include <objc/runtime.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

static const char *LOG_PATH = "/var/mobile/Library/Logs/sbnetprobe.log";

static void log_line(const char *msg) {
    FILE *f = fopen(LOG_PATH, "a");
    if (!f) return;
    time_t t = time(NULL);
    struct tm tmv;
    localtime_r(&t, &tmv);
    char ts[32];
    strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S", &tmv);
    fprintf(f, "%s %s\n", ts, msg);
    fclose(f);
}

static int contains_any(const char *name) {
    if (!name) return 0;
    const char *needles[] = {
        "WiFi", "Wifi", "wifi",
        "Cellular", "cellular",
        "Telephony", "telephony",
        "Radio", "radio",
        "DataUsage", "DataNetwork",
        "NetworkController",
        "Airplane",
        NULL
    };
    for (int i = 0; needles[i]; i++) {
        if (strstr(name, needles[i])) return 1;
    }
    return 0;
}

__attribute__((constructor))
static void sbnetprobe_ctor(void) {
    log_line("sbnetprobe 0.1.1 ctor entered");

    int count = objc_getClassList(NULL, 0);
    char line[512];
    snprintf(line, sizeof(line), "pid=%ld class_count=%d", (long)getpid(), count);
    log_line(line);
    if (count <= 0) {
        log_line("safe_result=read_only_no_network_change");
        return;
    }

    Class *classes = (Class *)calloc((size_t)count, sizeof(Class));
    if (!classes) {
        log_line("calloc failed");
        return;
    }

    int got = objc_getClassList(classes, count);
    int matched = 0;
    for (int i = 0; i < got; i++) {
        const char *name = class_getName(classes[i]);
        if (!contains_any(name)) continue;
        matched++;
        snprintf(line, sizeof(line), "class=%s", name);
        log_line(line);
    }
    free(classes);

    snprintf(line, sizeof(line), "matched=%d", matched);
    log_line(line);
    log_line("safe_result=read_only_no_network_change");
}

