(function () {
  "use strict";

  var zoom = 1;
  var minZoom = 0.5;
  var maxZoom = 2.5;
  var step = 0.1;

  function updateZoom() {
    var wrap = document.getElementById("screen-wrap");
    if (!wrap) return;
    wrap.style.transform = "scale(" + zoom.toFixed(2) + ")";
    wrap.style.width = (500 * zoom) + "px";
    wrap.style.height = (400 * zoom) + "px";
  }

  function bind(id, fn) {
    var el = document.getElementById(id);
    if (el) el.addEventListener("click", fn);
  }

  document.addEventListener("DOMContentLoaded", function () {
    bind("zoom-in-button", function () {
      zoom = Math.min(maxZoom, Math.round((zoom + step) * 10) / 10);
      updateZoom();
    });
    bind("zoom-out-button", function () {
      zoom = Math.max(minZoom, Math.round((zoom - step) * 10) / 10);
      updateZoom();
    });
    bind("zoom-reset-button", function () {
      zoom = 1;
      updateZoom();
    });
    updateZoom();
  });
})();
