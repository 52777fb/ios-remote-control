(function () {
  "use strict";

  var gestureSocket = null;

  function connectGestureSocket() {
    if (gestureSocket && gestureSocket.readyState === WebSocket.OPEN) return;
    var host = location.hostname || "127.0.0.1";
    gestureSocket = new WebSocket("ws://" + host + ":58587/");
    gestureSocket.binaryType = "arraybuffer";
    gestureSocket.onmessage = function () {};
  }

  function sendGesture(message) {
    connectGestureSocket();
    if (!gestureSocket || gestureSocket.readyState !== WebSocket.OPEN) return false;
    gestureSocket.send(JSON.stringify(message));
    return true;
  }

  function canvasPoint() {
    var canvas = document.getElementById("all_canvas");
    return {
      x: Math.round((canvas && canvas.width ? canvas.width : 500) / 2),
      y: Math.round((canvas && canvas.height ? canvas.height : 400) / 2)
    };
  }

  function pinch(kind) {
    var center = canvasPoint();
    var start = kind === "out" ? 28 : 120;
    var end = kind === "out" ? 120 : 28;
    var frames = [];
    var count = 10;
    for (var i = 0; i <= count; i++) {
      var d = Math.round(start + (end - start) * (i / count));
      frames.push({
        p1: { id: 1, x: center.x - d, y: center.y },
        p2: { id: 2, x: center.x + d, y: center.y }
      });
    }
    sendGesture({
      type: "gesture",
      gesture: kind === "out" ? "pinch_out" : "pinch_in",
      action: "pinch",
      center: center,
      frames: frames
    });
  }

  function bind(id, fn) {
    var el = document.getElementById(id);
    if (el) el.addEventListener("click", fn);
  }

  document.addEventListener("DOMContentLoaded", function () {
    connectGestureSocket();
    bind("pinch-out-button", function () { pinch("out"); });
    bind("pinch-in-button", function () { pinch("in"); });
  });
})();
