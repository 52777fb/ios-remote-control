#include <objc/runtime.h>
#include <objc/message.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

static const char *LOG_PATH = "/var/mobile/Library/Logs/sbnetprobe.log";
static const char *CMD_PATH = "/var/mobile/Library/Preferences/com.ctf.sbnetprobe.cmd";

static void log_line(const char *msg) {
    FILE *f = fopen(LOG_PATH, "a");
    if (!f) return;
    time_t t = time(NULL);
    struct tm tmv;
    localtime_r(&t, &tmv);
    char ts[32];
    strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S", &tmv);
    fprintf(f, "%s %s\n", ts, msg);
    fclose(f);
}

static int contains_any(const char *name) {
    if (!name) return 0;
    const char *needles[] = {
        "WiFi", "Wifi", "wifi",
        "Cellular", "cellular",
        "Telephony", "telephony",
        "Radio", "radio",
        "DataUsage", "DataNetwork",
        "NetworkController",
        "Airplane",
        NULL
    };
    for (int i = 0; needles[i]; i++) {
        if (strstr(name, needles[i])) return 1;
    }
    return 0;
}

static id shared_wifi_manager(void) {
    Class cls = objc_getClass("SBWiFiManager");
    if (!cls) return nil;
    SEL sharedSel = sel_registerName("sharedInstance");
    if (!class_getClassMethod(cls, sharedSel)) return nil;
    id (*sendId)(id, SEL) = (id (*)(id, SEL))objc_msgSend;
    return sendId((id)cls, sharedSel);
}

static int wifi_bool(id mgr, const char *selectorName, int fallback) {
    if (!mgr) return fallback;
    SEL sel = sel_registerName(selectorName);
    Class cls = object_getClass(mgr);
    if (!class_getInstanceMethod(cls, sel)) return fallback;
    BOOL (*sendBool)(id, SEL) = (BOOL (*)(id, SEL))objc_msgSend;
    return sendBool(mgr, sel) ? 1 : 0;
}

static void set_wifi_enabled_guarded(int enabled) {
    char line[256];
    id mgr = shared_wifi_manager();
    if (!mgr) {
        log_line("wifi_control manager_missing");
        return;
    }

    int beforeEnabled = wifi_bool(mgr, "wiFiEnabled", -1);
    int beforePowered = wifi_bool(mgr, "isPowered", -1);
    snprintf(line, sizeof(line), "wifi_control before enabled=%d powered=%d target=%d", beforeEnabled, beforePowered, enabled);
    log_line(line);

    void (*sendSetBool)(id, SEL, BOOL) = (void (*)(id, SEL, BOOL))objc_msgSend;
    SEL setEnabledSel = sel_registerName("setWiFiEnabled:");
    SEL setPoweredSel = sel_registerName("setPowered:");
    Class cls = object_getClass(mgr);
    if (class_getInstanceMethod(cls, setEnabledSel)) {
        sendSetBool(mgr, setEnabledSel, enabled ? YES : NO);
        log_line(enabled ? "wifi_control setWiFiEnabled:YES sent" : "wifi_control setWiFiEnabled:NO sent");
    } else if (class_getInstanceMethod(cls, setPoweredSel)) {
        sendSetBool(mgr, setPoweredSel, enabled ? YES : NO);
        log_line(enabled ? "wifi_control setPowered:YES sent" : "wifi_control setPowered:NO sent");
    } else {
        log_line("wifi_control setter_missing");
        return;
    }

    usleep(300000);
    int afterEnabled = wifi_bool(mgr, "wiFiEnabled", -1);
    int afterPowered = wifi_bool(mgr, "isPowered", -1);
    snprintf(line, sizeof(line), "wifi_control after enabled=%d powered=%d", afterEnabled, afterPowered);
    log_line(line);
}

static void *wifi_cycle_thread(void *arg) {
    int seconds = (int)(long)arg;
    if (seconds < 1) seconds = 1;
    if (seconds > 10) seconds = 10;

    char line[128];
    snprintf(line, sizeof(line), "wifi_cycle begin seconds=%d", seconds);
    log_line(line);

    set_wifi_enabled_guarded(0);
    sleep((unsigned int)seconds);
    set_wifi_enabled_guarded(1);

    log_line("wifi_cycle restored");
    return NULL;
}

static void start_wifi_cycle(int seconds) {
    pthread_t th;
    if (pthread_create(&th, NULL, wifi_cycle_thread, (void *)(long)seconds) == 0) {
        pthread_detach(th);
    } else {
        log_line("wifi_cycle pthread_create_failed");
    }
}

static int read_command_seconds(void) {
    FILE *f = fopen(CMD_PATH, "r");
    if (!f) return 0;
    char buf[128] = {0};
    fgets(buf, sizeof(buf), f);
    fclose(f);

    int seconds = 0;
    if (sscanf(buf, "wifi-cycle %d", &seconds) == 1) return seconds;
    return 0;
}

static void *command_poll_thread(void *arg) {
    (void)arg;
    time_t last_mtime = 0;
    off_t last_size = -1;
    for (;;) {
        struct stat st;
        if (stat(CMD_PATH, &st) == 0) {
            if (st.st_mtime != last_mtime || st.st_size != last_size) {
                last_mtime = st.st_mtime;
                last_size = st.st_size;
                int seconds = read_command_seconds();
                if (seconds > 0) start_wifi_cycle(seconds);
            }
        }
        sleep(1);
    }
    return NULL;
}

static void start_command_poll(void) {
    pthread_t th;
    if (pthread_create(&th, NULL, command_poll_thread, NULL) == 0) {
        pthread_detach(th);
        log_line("cmd_poll started path=/var/mobile/Library/Preferences/com.ctf.sbnetprobe.cmd");
    } else {
        log_line("cmd_poll pthread_create_failed");
    }
}

static void log_methods_for_class(const char *class_name) {
    char line[768];
    Class cls = objc_getClass(class_name);
    if (!cls) {
        snprintf(line, sizeof(line), "target_class=%s missing", class_name);
        log_line(line);
        return;
    }

    snprintf(line, sizeof(line), "target_class=%s present", class_name);
    log_line(line);

    unsigned int count = 0;
    Method *methods = class_copyMethodList(cls, &count);
    snprintf(line, sizeof(line), "target_class=%s instance_method_count=%u", class_name, count);
    log_line(line);
    for (unsigned int i = 0; methods && i < count; i++) {
        SEL sel = method_getName(methods[i]);
        const char *name = sel_getName(sel);
        snprintf(line, sizeof(line), "target_class=%s instance_method=%s", class_name, name ? name : "(null)");
        log_line(line);
    }
    if (methods) free(methods);

    Class meta = object_getClass(cls);
    count = 0;
    methods = class_copyMethodList(meta, &count);
    snprintf(line, sizeof(line), "target_class=%s class_method_count=%u", class_name, count);
    log_line(line);
    for (unsigned int i = 0; methods && i < count; i++) {
        SEL sel = method_getName(methods[i]);
        const char *name = sel_getName(sel);
        snprintf(line, sizeof(line), "target_class=%s class_method=%s", class_name, name ? name : "(null)");
        log_line(line);
    }
    if (methods) free(methods);
}

static void probe_sb_wifi_manager(void) {
    char line[512];
    Class cls = objc_getClass("SBWiFiManager");
    if (!cls) {
        log_line("wifi_probe=missing_class");
        return;
    }

    SEL sharedSel = sel_registerName("sharedInstance");
    if (!class_getClassMethod(cls, sharedSel)) {
        log_line("wifi_probe=missing_sharedInstance");
        return;
    }

    id (*sendId)(id, SEL) = (id (*)(id, SEL))objc_msgSend;
    BOOL (*sendBool)(id, SEL) = (BOOL (*)(id, SEL))objc_msgSend;

    id mgr = sendId((id)cls, sharedSel);
    snprintf(line, sizeof(line), "wifi_probe_manager=%p", mgr);
    log_line(line);
    if (!mgr) return;

    const char *boolSelectors[] = {
        "wiFiEnabled",
        "isPowered",
        "isAssociated",
        "isPrimaryInterface",
        "isAssociatedToIOSHotspot",
        NULL
    };
    for (int i = 0; boolSelectors[i]; i++) {
        SEL sel = sel_registerName(boolSelectors[i]);
        if (!class_getInstanceMethod(cls, sel)) {
            snprintf(line, sizeof(line), "wifi_probe %s=missing", boolSelectors[i]);
            log_line(line);
            continue;
        }
        BOOL value = sendBool(mgr, sel);
        snprintf(line, sizeof(line), "wifi_probe %s=%d", boolSelectors[i], value ? 1 : 0);
        log_line(line);
    }

    id (*sendObj)(id, SEL) = (id (*)(id, SEL))objc_msgSend;
    SEL nameSel = sel_registerName("currentNetworkName");
    if (class_getInstanceMethod(cls, nameSel)) {
        id name = sendObj(mgr, nameSel);
        const char *networkName = "(non-string)";
        SEL utf8Sel = sel_registerName("UTF8String");
        if (name && class_getInstanceMethod(object_getClass(name), utf8Sel)) {
            const char *(*sendCString)(id, SEL) = (const char *(*)(id, SEL))objc_msgSend;
            const char *s = sendCString(name, utf8Sel);
            if (s) networkName = s;
        } else if (!name) {
            networkName = "(null)";
        }
        snprintf(line, sizeof(line), "wifi_probe currentNetworkName=%s", networkName);
        log_line(line);
    }
}

__attribute__((constructor))
static void sbnetprobe_ctor(void) {
    log_line("sbnetprobe 0.1.4 ctor entered");
    start_command_poll();

    int count = objc_getClassList(NULL, 0);
    char line[512];
    snprintf(line, sizeof(line), "pid=%ld class_count=%d", (long)getpid(), count);
    log_line(line);
    if (count <= 0) {
        log_line("safe_result=read_only_no_network_change");
        return;
    }

    Class *classes = (Class *)calloc((size_t)count, sizeof(Class));
    if (!classes) {
        log_line("calloc failed");
        return;
    }

    int got = objc_getClassList(classes, count);
    int matched = 0;
    for (int i = 0; i < got; i++) {
        const char *name = class_getName(classes[i]);
        if (!contains_any(name)) continue;
        matched++;
        snprintf(line, sizeof(line), "class=%s", name);
        log_line(line);
    }
    free(classes);

    snprintf(line, sizeof(line), "matched=%d", matched);
    log_line(line);

    const char *targets[] = {
        "SBWiFiManager",
        "SBTelephonyManager",
        "SBAirplaneModeController",
        "RadiosPreferences",
        "CTCellularData",
        "CoreTelephonyClient",
        "PSCellularDataSettingsDetail",
        "PSWiFiSettingsDetail",
        NULL
    };
    for (int i = 0; targets[i]; i++) {
        log_methods_for_class(targets[i]);
    }

    probe_sb_wifi_manager();

    log_line("safe_result=read_only_no_network_change");
}
