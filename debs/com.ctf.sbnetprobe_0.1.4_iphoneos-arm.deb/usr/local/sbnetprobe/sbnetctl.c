#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>

static const char *CMD_PATH = "/var/mobile/Library/Preferences/com.ctf.sbnetprobe.cmd";

static void usage(void) {
    puts("usage:");
    puts("  sbnetctl wifi-cycle <seconds>");
    puts("seconds is clamped by SpringBoard tweak to 1..10");
}

int main(int argc, char **argv) {
    if (argc != 3 || strcmp(argv[1], "wifi-cycle") != 0) {
        usage();
        return 2;
    }

    int seconds = atoi(argv[2]);
    if (seconds <= 0) {
        usage();
        return 2;
    }

    mkdir("/var/mobile/Library/Preferences", 0755);
    FILE *f = fopen(CMD_PATH, "w");
    if (!f) {
        perror("open command file");
        return 1;
    }
    fprintf(f, "wifi-cycle %d %ld\n", seconds, (long)time(NULL));
    fclose(f);

    printf("scheduled wifi-cycle seconds=%d path=%s\n", seconds, CMD_PATH);
    return 0;
}
