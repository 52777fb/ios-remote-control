#import <Foundation/Foundation.h>
#import <objc/message.h>
#import <objc/runtime.h>
#import <dlfcn.h>

static NSString *LogPath(void) {
    return @"/var/mobile/Library/Logs/msgsend.log";
}

static void LogLine(NSString *line) {
    @autoreleasepool {
        NSDateFormatter *fmt = [NSDateFormatter new];
        fmt.dateFormat = @"yyyy-MM-dd HH:mm:ss";
        NSString *out = [NSString stringWithFormat:@"%@ %@\n", [fmt stringFromDate:[NSDate date]], line];
        NSData *data = [out dataUsingEncoding:NSUTF8StringEncoding];
        NSFileManager *fm = [NSFileManager defaultManager];
        NSString *dir = [LogPath() stringByDeletingLastPathComponent];
        [fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
        if (![fm fileExistsAtPath:LogPath()]) {
            [data writeToFile:LogPath() atomically:YES];
            return;
        }
        NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:LogPath()];
        [fh seekToEndOfFile];
        [fh writeData:data];
        [fh closeFile];
    }
}

static NSString *JoinText(int argc, char **argv) {
    NSMutableArray *parts = [NSMutableArray array];
    for (int i = 2; i < argc; i++) {
        NSString *s = [[NSString alloc] initWithBytes:argv[i] length:strlen(argv[i]) encoding:NSUTF8StringEncoding];
        if (!s) s = [NSString stringWithUTF8String:argv[i]];
        [parts addObject:s ?: @""];
    }
    return [parts componentsJoinedByString:@" "];
}

static BOOL CallVoid3(id target, SEL sel, id a, id b, id c) {
    if (!target || ![target respondsToSelector:sel]) return NO;
    ((void (*)(id, SEL, id, id, id))objc_msgSend)(target, sel, a, b, c);
    return YES;
}

static BOOL CallVoid4(id target, SEL sel, id a, id b, id c, id d) {
    if (!target || ![target respondsToSelector:sel]) return NO;
    ((void (*)(id, SEL, id, id, id, id))objc_msgSend)(target, sel, a, b, c, d);
    return YES;
}

int main(int argc, char **argv) {
    @autoreleasepool {
        if (argc < 3) {
            fprintf(stderr, "usage: msgsend <to> <text>\n");
            fprintf(stderr, "example: msgsend +8613800138000 hello\n");
            return 2;
        }

        NSString *to = [[NSString alloc] initWithBytes:argv[1] length:strlen(argv[1]) encoding:NSUTF8StringEncoding];
        NSString *text = JoinText(argc, argv);
        if (to.length == 0 || text.length == 0) {
            fprintf(stderr, "empty recipient or text\n");
            return 2;
        }

        LogLine([NSString stringWithFormat:@"msgsend 0.1.0 start to=%@ text_len=%lu", to, (unsigned long)text.length]);

        void *ct = dlopen("/System/Library/Frameworks/CoreTelephony.framework/CoreTelephony", RTLD_NOW);
        if (!ct) {
            LogLine([NSString stringWithFormat:@"dlopen CoreTelephony failed: %s", dlerror()]);
        }

        Class centerClass = NSClassFromString(@"CTMessageCenter");
        if (!centerClass) {
            LogLine(@"CTMessageCenter missing");
            fprintf(stderr, "CTMessageCenter missing\n");
            return 1;
        }

        SEL sharedSel = NSSelectorFromString(@"sharedMessageCenter");
        if (![centerClass respondsToSelector:sharedSel]) {
            LogLine(@"sharedMessageCenter missing");
            fprintf(stderr, "sharedMessageCenter missing\n");
            return 1;
        }

        id center = ((id (*)(id, SEL))objc_msgSend)((id)centerClass, sharedSel);
        if (!center) {
            LogLine(@"sharedMessageCenter returned nil");
            fprintf(stderr, "message center nil\n");
            return 1;
        }

        SEL sel1 = NSSelectorFromString(@"sendSMSWithText:serviceCenter:toAddress:");
        @try {
            if (CallVoid3(center, sel1, text, nil, to)) {
                LogLine(@"sent via sendSMSWithText:serviceCenter:toAddress:");
                printf("sent via CTMessageCenter selector1\n");
                return 0;
            }
        } @catch (NSException *e) {
            LogLine([NSString stringWithFormat:@"selector1 exception %@ %@", e.name, e.reason]);
        }

        SEL sel2 = NSSelectorFromString(@"sendSMSWithText:text:serviceCenter:toAddress:");
        @try {
            if (CallVoid4(center, sel2, text, text, nil, to)) {
                LogLine(@"sent via sendSMSWithText:text:serviceCenter:toAddress:");
                printf("sent via CTMessageCenter selector2\n");
                return 0;
            }
        } @catch (NSException *e) {
            LogLine([NSString stringWithFormat:@"selector2 exception %@ %@", e.name, e.reason]);
        }

        LogLine(@"no supported CTMessageCenter send selector worked");
        fprintf(stderr, "no supported send selector worked\n");
        return 1;
    }
}
