(function () {
  "use strict";

  var gestureSocket = null;
  var pendingMessages = [];
  var remoteWidth = 0;
  var remoteHeight = 0;

  function connectGestureSocket() {
    if (gestureSocket && gestureSocket.readyState === WebSocket.OPEN) return;
    if (gestureSocket && gestureSocket.readyState === WebSocket.CONNECTING) return;
    var host = location.hostname || "127.0.0.1";
    gestureSocket = new WebSocket("ws://" + host + ":58587/");
    gestureSocket.binaryType = "arraybuffer";
    gestureSocket.onopen = function () {
      while (pendingMessages.length && gestureSocket.readyState === WebSocket.OPEN) {
        gestureSocket.send(JSON.stringify(pendingMessages.shift()));
      }
    };
    gestureSocket.onmessage = function (event) {
      if (typeof event.data !== "string") return;
      try {
        var msg = JSON.parse(event.data);
        if (msg && msg.width && msg.height) {
          remoteWidth = Number(msg.width) || remoteWidth;
          remoteHeight = Number(msg.height) || remoteHeight;
        }
      } catch (_) {}
    };
    gestureSocket.onclose = function () {
      gestureSocket = null;
    };
  }

  function sendGesture(message) {
    connectGestureSocket();
    if (!gestureSocket || gestureSocket.readyState !== WebSocket.OPEN) {
      pendingMessages.push(message);
      return false;
    }
    gestureSocket.send(JSON.stringify(message));
    return true;
  }

  function setStatus(text) {
    var el = document.getElementById("clip-status");
    if (el) el.textContent = text || "";
  }

  function sendKey(key) {
    sendGesture({ type: "key", key: key });
  }

  function typeText(text) {
    if (!text) return;
    var i = 0;
    setStatus("发送中...");
    function step() {
      if (i >= text.length) {
        setStatus("已发送");
        return;
      }
      var ch = text.charAt(i++);
      if (ch === "\n") ch = "Enter";
      if (ch === "\r") return step();
      sendKey(ch);
      setTimeout(step, 18);
    }
    step();
  }

  function fallbackCopy(text) {
    var area = document.createElement("textarea");
    area.value = text;
    document.body.appendChild(area);
    area.focus();
    area.select();
    try {
      document.execCommand("copy");
      setStatus("已复制");
    } catch (_) {
      setStatus("复制失败，请手动复制");
    }
    document.body.removeChild(area);
  }

  function canvasPoint() {
    var canvas = document.getElementById("all_canvas");
    return {
      x: Math.round((remoteWidth || (canvas && canvas.width) || 500) / 2),
      y: Math.round((remoteHeight || (canvas && canvas.height) || 400) / 2)
    };
  }

  function pinch(kind) {
    var center = canvasPoint();
    var base = Math.max(80, Math.min(remoteWidth || 500, remoteHeight || 400) * 0.16);
    var start = kind === "out" ? base * 0.35 : base * 1.35;
    var end = kind === "out" ? base * 1.35 : base * 0.35;
    var frames = [];
    var count = 16;
    for (var i = 0; i <= count; i++) {
      var d = Math.round(start + (end - start) * (i / count));
      frames.push({
        p1: { id: 1, x: center.x - d, y: center.y },
        p2: { id: 2, x: center.x + d, y: center.y }
      });
    }
    sendGesture({
      type: "gesture",
      gesture: kind === "out" ? "pinch_out" : "pinch_in",
      action: "pinch",
      center: center,
      frames: frames
    });
  }

  function bind(id, fn) {
    var el = document.getElementById(id);
    if (el) el.addEventListener("click", fn);
  }

  document.addEventListener("DOMContentLoaded", function () {
    connectGestureSocket();
    bind("pinch-out-button", function () { pinch("out"); });
    bind("pinch-in-button", function () { pinch("in"); });
    bind("clip-read-button", function () {
      var box = document.getElementById("clip-text");
      if (!navigator.clipboard || !navigator.clipboard.readText) {
        setStatus("浏览器不允许读取，请手动 Ctrl+V");
        if (box) box.focus();
        return;
      }
      navigator.clipboard.readText().then(function (text) {
        if (box) box.value = text;
        setStatus("已读取");
      }).catch(function () {
        setStatus("读取失败，请手动 Ctrl+V");
        if (box) box.focus();
      });
    });
    bind("clip-send-button", function () {
      var box = document.getElementById("clip-text");
      typeText(box ? box.value : "");
    });
    bind("clip-copy-button", function () {
      var box = document.getElementById("clip-text");
      var text = box ? box.value : "";
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function () {
          setStatus("已复制");
        }).catch(function () {
          fallbackCopy(text);
        });
      } else {
        fallbackCopy(text);
      }
    });
  });
})();
