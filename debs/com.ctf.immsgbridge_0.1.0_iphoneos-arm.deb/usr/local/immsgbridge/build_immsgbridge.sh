#!/bin/sh
set -u

echo "immsgbridge build"
date
echo "version=0.1.0"
echo "sms_fallback=disabled"

if ! command -v clang >/dev/null 2>&1; then
  echo "clang missing"
  exit 0
fi

SDK=""
for d in /usr/share/SDKs/iPhoneOS.sdk /var/jb/usr/share/SDKs/iPhoneOS.sdk /var/mobile/theos/sdks/iPhoneOS*.sdk; do
  [ -d "$d" ] && { SDK="$d"; break; }
done

COMMON="-arch arm64 -miphoneos-version-min=13.0 -fobjc-arc -lobjc -framework Foundation"
if [ -n "$SDK" ]; then
  echo "sdk=$SDK"
  clang -isysroot "$SDK" $COMMON -dynamiclib /usr/local/immsgbridge/immsgbridge.m -o /usr/lib/TweakInject/immsgbridge.dylib
  clang -isysroot "$SDK" $COMMON /usr/local/immsgbridge/immsgsend.m -o /usr/bin/immsgsend
else
  echo "sdk=none"
  clang $COMMON -dynamiclib /usr/local/immsgbridge/immsgbridge.m -o /usr/lib/TweakInject/immsgbridge.dylib
  clang $COMMON /usr/local/immsgbridge/immsgsend.m -o /usr/bin/immsgsend
fi

cat > /usr/lib/TweakInject/immsgbridge.plist <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Filter</key>
  <dict>
    <key>Bundles</key>
    <array>
      <string>com.apple.MobileSMS</string>
    </array>
  </dict>
</dict>
</plist>
EOF

cat > /usr/bin/msgsend <<'EOF'
#!/bin/sh
exec /usr/bin/immsgsend "$@"
EOF

chmod 755 /usr/lib/TweakInject/immsgbridge.dylib /usr/bin/immsgsend /usr/bin/msgsend
chmod 644 /usr/lib/TweakInject/immsgbridge.plist
if command -v ldid >/dev/null 2>&1; then
  ldid -S /usr/lib/TweakInject/immsgbridge.dylib || true
  ldid -S /usr/bin/immsgsend || true
fi

ls -lh /usr/lib/TweakInject/immsgbridge.dylib /usr/lib/TweakInject/immsgbridge.plist /usr/bin/immsgsend /usr/bin/msgsend
exit 0
