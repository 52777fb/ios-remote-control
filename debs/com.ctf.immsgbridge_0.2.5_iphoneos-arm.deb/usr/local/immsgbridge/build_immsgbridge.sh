#!/bin/sh
set -u

echo "immsgbridge build"
date
echo "version=0.2.5-continuous"
echo "sms_fallback=disabled"

if ! command -v clang >/dev/null 2>&1; then
  echo "clang missing"
  exit 0
fi

SDK=""
for d in /usr/share/SDKs/iPhoneOS.sdk /var/jb/usr/share/SDKs/iPhoneOS.sdk /var/mobile/theos/sdks/iPhoneOS*.sdk; do
  [ -d "$d" ] && { SDK="$d"; break; }
done

COMMON="-arch arm64 -miphoneos-version-min=13.0 -fobjc-arc -lobjc -framework Foundation"
if [ -n "$SDK" ]; then
  echo "sdk=$SDK"
  clang -isysroot "$SDK" $COMMON -dynamiclib /usr/local/immsgbridge/immsgbridge.m -o /usr/lib/TweakInject/immsgbridge.dylib
  clang -isysroot "$SDK" $COMMON /usr/local/immsgbridge/immsgsend.m -o /usr/bin/immsgsend
  clang -isysroot "$SDK" $COMMON /usr/local/immsgbridge/immsgforwardd.m -lsqlite3 -o /usr/bin/immsgforwardd
else
  echo "sdk=none"
  clang $COMMON -dynamiclib /usr/local/immsgbridge/immsgbridge.m -o /usr/lib/TweakInject/immsgbridge.dylib
  clang $COMMON /usr/local/immsgbridge/immsgsend.m -o /usr/bin/immsgsend
  clang $COMMON /usr/local/immsgbridge/immsgforwardd.m -lsqlite3 -o /usr/bin/immsgforwardd
fi

cat > /usr/lib/TweakInject/immsgbridge.plist <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Filter</key>
  <dict>
    <key>Bundles</key>
    <array>
      <string>com.apple.MobileSMS</string>
    </array>
    <key>Executables</key>
    <array>
      <string>MobileSMS</string>
    </array>
  </dict>
</dict>
</plist>
EOF

cat > /usr/bin/msgsend <<'EOF'
#!/bin/sh
exec /usr/bin/immsgsend "$@"
EOF

chmod 755 /usr/lib/TweakInject/immsgbridge.dylib /usr/bin/immsgsend /usr/bin/msgsend
chmod 755 /usr/bin/immsgforwardd
chmod 644 /usr/lib/TweakInject/immsgbridge.plist
if command -v ldid >/dev/null 2>&1; then
  ldid -S /usr/lib/TweakInject/immsgbridge.dylib || true
  ldid -S /usr/bin/immsgsend || true
  ldid -S /usr/bin/immsgforwardd || true
fi

cat > /Library/LaunchDaemons/com.ctf.immsgforwardd.plist <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.ctf.immsgforwardd</string>
  <key>ProgramArguments</key>
  <array>
    <string>/usr/bin/immsgforwardd</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>UserName</key>
  <string>mobile</string>
</dict>
</plist>
EOF
chmod 644 /Library/LaunchDaemons/com.ctf.immsgforwardd.plist
launchctl unload /Library/LaunchDaemons/com.ctf.immsgforwardd.plist 2>/dev/null || true
launchctl load /Library/LaunchDaemons/com.ctf.immsgforwardd.plist 2>/dev/null || true

ls -lh /usr/lib/TweakInject/immsgbridge.dylib /usr/lib/TweakInject/immsgbridge.plist /usr/bin/immsgsend /usr/bin/msgsend /usr/bin/immsgforwardd /Library/LaunchDaemons/com.ctf.immsgforwardd.plist
exit 0
