#import <Foundation/Foundation.h>
#import <objc/message.h>
#import <objc/runtime.h>
#import <dlfcn.h>

static NSString *CmdPath(void) { return @"/var/mobile/Library/Preferences/com.ctf.immsgbridge.cmd.plist"; }
static NSString *ResultPath(void) { return @"/var/mobile/Library/Preferences/com.ctf.immsgbridge.result.plist"; }
static NSString *LogPath(void) { return @"/var/mobile/Library/Logs/immsgbridge.log"; }
static NSString *gLastNonce = nil;

static void LogLine(NSString *line) {
    @autoreleasepool {
        NSDateFormatter *fmt = [NSDateFormatter new];
        fmt.dateFormat = @"yyyy-MM-dd HH:mm:ss";
        NSString *out = [NSString stringWithFormat:@"%@ %@\n", [fmt stringFromDate:[NSDate date]], line];
        NSData *data = [out dataUsingEncoding:NSUTF8StringEncoding];
        NSFileManager *fm = [NSFileManager defaultManager];
        [fm createDirectoryAtPath:[LogPath() stringByDeletingLastPathComponent] withIntermediateDirectories:YES attributes:nil error:nil];
        if (![fm fileExistsAtPath:LogPath()]) { [data writeToFile:LogPath() atomically:YES]; return; }
        NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:LogPath()];
        [fh seekToEndOfFile]; [fh writeData:data]; [fh closeFile];
    }
}

static id C0(Class cls, NSString *s) {
    SEL sel = NSSelectorFromString(s);
    if (!cls || ![cls respondsToSelector:sel]) return nil;
    return ((id(*)(id,SEL))objc_msgSend)((id)cls, sel);
}
static id O0(id obj, NSString *s) {
    SEL sel = NSSelectorFromString(s);
    if (!obj || ![obj respondsToSelector:sel]) return nil;
    return ((id(*)(id,SEL))objc_msgSend)(obj, sel);
}
static BOOL V2(id obj, NSString *s, id a, id b) {
    SEL sel = NSSelectorFromString(s);
    if (!obj || ![obj respondsToSelector:sel]) return NO;
    ((void(*)(id,SEL,id,id))objc_msgSend)(obj, sel, a, b);
    return YES;
}
static BOOL V3(id obj, NSString *s, id a, id b, BOOL c) {
    SEL sel = NSSelectorFromString(s);
    if (!obj || ![obj respondsToSelector:sel]) return NO;
    ((void(*)(id,SEL,id,id,BOOL))objc_msgSend)(obj, sel, a, b, c);
    return YES;
}
static id O1(id obj, NSString *s, id a) {
    SEL sel = NSSelectorFromString(s);
    if (!obj || ![obj respondsToSelector:sel]) return nil;
    return ((id(*)(id,SEL,id))objc_msgSend)(obj, sel, a);
}
static id Init1(Class cls, NSString *s, id a) {
    if (!cls) return nil;
    id obj = ((id(*)(id,SEL))objc_msgSend)((id)cls, NSSelectorFromString(@"alloc"));
    SEL sel = NSSelectorFromString(s);
    if (!obj || ![obj respondsToSelector:sel]) return nil;
    return ((id(*)(id,SEL,id))objc_msgSend)(obj, sel, a);
}
static id Init2(Class cls, NSString *s, id a, id b) {
    if (!cls) return nil;
    id obj = ((id(*)(id,SEL))objc_msgSend)((id)cls, NSSelectorFromString(@"alloc"));
    SEL sel = NSSelectorFromString(s);
    if (!obj || ![obj respondsToSelector:sel]) return nil;
    return ((id(*)(id,SEL,id,id))objc_msgSend)(obj, sel, a, b);
}

static NSString *Desc(id obj) {
    if (!obj) return @"nil";
    @try { return [obj description] ?: @"<desc nil>"; }
    @catch (__unused NSException *e) { return [NSString stringWithFormat:@"<%@ %p>", NSStringFromClass([obj class]), obj]; }
}

static id Singleton(NSString *name) {
    Class cls = NSClassFromString(name);
    for (NSString *s in @[@"sharedInstance", @"sharedRegistry", @"sharedController", @"defaultController"]) {
        id v = C0(cls, s);
        if (v) { LogLine([NSString stringWithFormat:@"%@ %@", name, s]); return v; }
    }
    return nil;
}

static id CurrentIMessageAccount(void) {
    id ac = Singleton(@"IMAccountController");
    if (!ac) return nil;
    for (NSString *s in @[@"activeIMessageAccount", @"mostLoggedInAccount"]) {
        @try {
            id v = O0(ac, s);
            LogLine([NSString stringWithFormat:@"account %@ => %@", s, Desc(v)]);
            if (v) return v;
        } @catch (NSException *e) { LogLine([NSString stringWithFormat:@"account %@ exception %@ %@", s, e.name, e.reason]); }
    }
    return nil;
}

static BOOL LooksIMessage(id obj) {
    NSString *d = [Desc(obj) lowercaseString];
    if ([d containsString:@"imessage"]) return YES;
    for (NSString *s in @[@"internalName", @"serviceName", @"name", @"displayName", @"identifier", @"accountID"]) {
        @try {
            id v = O0(obj, s);
            if ([[Desc(v) lowercaseString] containsString:@"imessage"]) return YES;
        } @catch (__unused NSException *e) {}
    }
    return NO;
}

static BOOL AccountLooksOnline(id account) {
    NSString *d = [Desc(account) lowercaseString];
    if ([d containsString:@"loginstatus: offline"] || [d containsString:@"active: no"]) {
        LogLine([NSString stringWithFormat:@"account_offline_or_inactive %@", Desc(account)]);
        return NO;
    }
    LogLine([NSString stringWithFormat:@"account_status_ok_or_unknown %@", Desc(account)]);
    return YES;
}

static BOOL ChatGuidLooksIMessage(id chat) {
    NSString *d = [[Desc(chat) lowercaseString] stringByReplacingOccurrencesOfString:@" " withString:@""];
    if ([d containsString:@"guid:imessage;-;"] || [d containsString:@"guid:imessage"]) {
        LogLine(@"chat_guid_confirmed_iMessage");
        return YES;
    }
    return NO;
}

static id MakeHandle(NSString *recipient, id account) {
    Class handleCls = NSClassFromString(@"IMHandle");
    if (!handleCls) return nil;
    for (NSString *name in @[@"initWithAccount:ID:alreadyCanonical:", @"initWithAccount:ID:", @"initWithID:account:"]) {
        @try {
            id obj = ((id(*)(id,SEL))objc_msgSend)((id)handleCls, NSSelectorFromString(@"alloc"));
            SEL sel = NSSelectorFromString(name);
            if (![obj respondsToSelector:sel]) continue;
            id h = nil;
            if ([name isEqualToString:@"initWithAccount:ID:alreadyCanonical:"])
                h = ((id(*)(id,SEL,id,id,BOOL))objc_msgSend)(obj, sel, account, recipient, NO);
            else if ([name isEqualToString:@"initWithAccount:ID:"])
                h = ((id(*)(id,SEL,id,id))objc_msgSend)(obj, sel, account, recipient);
            else
                h = ((id(*)(id,SEL,id,id))objc_msgSend)(obj, sel, recipient, account);
            if (h) { LogLine([NSString stringWithFormat:@"handle via %@ %@", name, Desc(h)]); return h; }
        } @catch (NSException *e) { LogLine([NSString stringWithFormat:@"handle %@ exception %@ %@", name, e.name, e.reason]); }
    }
    return nil;
}

static id MakeMessage(NSString *text) {
    @try {
        Class msgCls = NSClassFromString(@"IMMessage");
        id body = [[NSAttributedString alloc] initWithString:text ?: @""];
        SEL sel = NSSelectorFromString(@"instantMessageWithText:flags:threadIdentifier:");
        if ([msgCls respondsToSelector:sel]) {
            id msg = ((id(*)(id,SEL,id,unsigned int,id))objc_msgSend)((id)msgCls, sel, body, 0u, nil);
            if (msg) {
                LogLine([NSString stringWithFormat:@"message via attributed instantMessageWithText %@", Desc(msg)]);
                return msg;
            }
        }
        sel = NSSelectorFromString(@"instantMessageWithText:messageSubject:flags:threadIdentifier:");
        if ([msgCls respondsToSelector:sel]) {
            id msg = ((id(*)(id,SEL,id,id,unsigned int,id))objc_msgSend)((id)msgCls, sel, body, nil, 0u, nil);
            if (msg) {
                LogLine([NSString stringWithFormat:@"message via attributed instantMessageWithText:subject %@", Desc(msg)]);
                return msg;
            }
        }
    } @catch (NSException *e) {
        LogLine([NSString stringWithFormat:@"MakeMessage exception %@ %@", e.name, e.reason]);
    }
    return nil;
}

static BOOL SendViaChatKit(id imChat, NSString *text, NSString **errOut) {
    @try {
        Class convCls = NSClassFromString(@"CKConversation");
        Class compCls = NSClassFromString(@"CKComposition");
        if (!convCls || !compCls) { if (errOut) *errOut = @"ChatKit classes missing"; return NO; }

        id conversation = Init1(convCls, @"initWithChat:", imChat);
        LogLine([NSString stringWithFormat:@"ck conversation %@", Desc(conversation)]);
        if (!conversation) { if (errOut) *errOut = @"CKConversation initWithChat failed"; return NO; }

        id ckText = [[NSAttributedString alloc] initWithString:text ?: @""];
        id composition = Init2(compCls, @"initWithText:subject:", ckText, nil);
        if (!composition && [compCls respondsToSelector:NSSelectorFromString(@"composition")]) {
            composition = ((id(*)(id,SEL))objc_msgSend)((id)compCls, NSSelectorFromString(@"composition"));
            composition = O1(composition, @"compositionByAppendingText:", ckText);
        }
        LogLine([NSString stringWithFormat:@"ck composition %@ text=%@", Desc(composition), Desc(O0(composition, @"text"))]);
        if (!composition) { if (errOut) *errOut = @"CKComposition create failed"; return NO; }

        NSError *canErr = nil;
        SEL canSel = NSSelectorFromString(@"canSendComposition:error:");
        if ([conversation respondsToSelector:canSel]) {
            BOOL canSend = ((BOOL(*)(id,SEL,id,NSError **))objc_msgSend)(conversation, canSel, composition, &canErr);
            LogLine([NSString stringWithFormat:@"ck canSend=%d err=%@", canSend, Desc(canErr)]);
            if (!canSend) { if (errOut) *errOut = [NSString stringWithFormat:@"CKConversation cannot send: %@", Desc(canErr)]; return NO; }
        }

        id message = O1(conversation, @"messageWithComposition:", composition);
        if (!message) message = O1(conversation, @"messagesFromComposition:", composition);
        LogLine([NSString stringWithFormat:@"ck message %@", Desc(message)]);
        if (!message) { if (errOut) *errOut = @"CKConversation messageWithComposition failed"; return NO; }

        SEL sendSel = NSSelectorFromString(@"sendMessage:newComposition:");
        if ([conversation respondsToSelector:sendSel]) {
            ((void(*)(id,SEL,id,BOOL))objc_msgSend)(conversation, sendSel, message, YES);
            return YES;
        }
        id service = O0(conversation, @"sendingService");
        sendSel = NSSelectorFromString(@"sendMessage:onService:newComposition:");
        if ([conversation respondsToSelector:sendSel]) {
            ((void(*)(id,SEL,id,id,BOOL))objc_msgSend)(conversation, sendSel, message, service, YES);
            return YES;
        }
        if (errOut) *errOut = @"no CKConversation send selector";
        return NO;
    } @catch (NSException *e) {
        if (errOut) *errOut = [NSString stringWithFormat:@"ChatKit send exception %@ %@", e.name, e.reason];
        return NO;
    }
}

static BOOL SendIMessageOnly(NSString *to, NSString *text, NSString **errOut) {
    void *a = dlopen("/System/Library/PrivateFrameworks/IMFoundation.framework/IMFoundation", RTLD_NOW);
    void *b = dlopen("/System/Library/PrivateFrameworks/IMCore.framework/IMCore", RTLD_NOW);
    void *c = dlopen("/System/Library/PrivateFrameworks/ChatKit.framework/ChatKit", RTLD_NOW);
    LogLine([NSString stringWithFormat:@"dlopen imfoundation=%d imcore=%d chatkit=%d", !!a, !!b, !!c]);

    id account = CurrentIMessageAccount();
    if (!account || !LooksIMessage(account)) {
        if (errOut) *errOut = @"no confirmed iMessage account in imagent";
        return NO;
    }
    BOOL accountOnline = AccountLooksOnline(account);

    id handle = nil;
    @try {
        handle = MakeHandle(to, account);
    } @catch (NSException *e) {
        if (errOut) *errOut = [NSString stringWithFormat:@"handle exception %@ %@", e.name, e.reason];
        return NO;
    }
    if (!handle) { if (errOut) *errOut = @"handle create failed"; return NO; }

    id registry = Singleton(@"IMChatRegistry");
    id chat = nil;
    @try {
        SEL sel = NSSelectorFromString(@"_ck_chatForHandles:createIfNecessary:");
        if ([registry respondsToSelector:sel])
            chat = ((id(*)(id,SEL,id,BOOL))objc_msgSend)(registry, sel, @[handle], YES);
    } @catch (NSException *e) { LogLine([NSString stringWithFormat:@"chat exception %@ %@", e.name, e.reason]); }
    LogLine([NSString stringWithFormat:@"chat %@", Desc(chat)]);
    if (!chat) { if (errOut) *errOut = @"chat create failed"; return NO; }

    @try {
    BOOL confirmedIMessageChat = NO;
    @try {
        confirmedIMessageChat = ChatGuidLooksIMessage(chat) || LooksIMessage(chat) || LooksIMessage(O0(chat, @"__ck_service"));
    } @catch (NSException *e) {
        LogLine([NSString stringWithFormat:@"chat confirm exception %@ %@", e.name, e.reason]);
    }
    if (!confirmedIMessageChat) {
        if (errOut) *errOut = @"chat not confirmed iMessage";
        return NO;
    }
    if (!accountOnline) LogLine(@"account offline/inactive but chat is confirmed iMessage; continuing without SMS fallback");
    } @catch (NSException *e) {
        if (errOut) *errOut = [NSString stringWithFormat:@"chat service exception %@ %@", e.name, e.reason];
        return NO;
    }

    if (SendViaChatKit(chat, text, errOut)) return YES;
    LogLine([NSString stringWithFormat:@"ck send failed %@", errOut ? (*errOut ?: @"") : @""]);

    if (errOut && (!*errOut || [*errOut length] == 0)) *errOut = @"ChatKit send failed";
    return NO;
}

static void WriteResult(NSString *nonce, BOOL ok, NSString *message) {
    NSDictionary *existing = [NSDictionary dictionaryWithContentsOfFile:ResultPath()];
    if (!ok && [existing isKindOfClass:[NSDictionary class]] &&
        [existing[@"nonce"] isEqualToString:nonce ?: @""] &&
        [existing[@"ok"] boolValue]) {
        LogLine([NSString stringWithFormat:@"preserve existing success for nonce=%@; ignoring later failure %@", nonce ?: @"", message ?: @""]);
        return;
    }
    NSDictionary *r = @{@"nonce": nonce ?: @"", @"ok": @(ok), @"message": message ?: @"", @"time": @([[NSDate date] timeIntervalSince1970])};
    [r writeToFile:ResultPath() atomically:YES];
}

static void PollOnce(void) {
    NSDictionary *cmd = [NSDictionary dictionaryWithContentsOfFile:CmdPath()];
    if (![cmd isKindOfClass:[NSDictionary class]]) return;
    NSString *nonce = cmd[@"nonce"];
    if (nonce.length == 0 || [nonce isEqualToString:gLastNonce]) return;
    NSString *to = cmd[@"to"];
    NSString *text = cmd[@"text"];
    if (to.length == 0 || text.length == 0) return;
    gLastNonce = [nonce copy];
    LogLine([NSString stringWithFormat:@"command nonce=%@ to=%@ text_len=%lu sms_fallback=disabled", nonce, to, (unsigned long)text.length]);
    NSString *err = nil;
    BOOL ok = SendIMessageOnly(to, text, &err);
    LogLine([NSString stringWithFormat:@"result ok=%d %@", ok, err ?: @""]);
    WriteResult(nonce, ok, ok ? @"sent_or_queued_iMessage_only" : err);
}

__attribute__((constructor))
static void InitBridge(void) {
    @autoreleasepool {
        NSString *bid = [[NSBundle mainBundle] bundleIdentifier] ?: @"";
        NSString *pname = [[NSProcessInfo processInfo] processName] ?: @"";
        LogLine([NSString stringWithFormat:@"immsgbridge 0.2.2 ctor bundle=%@ process=%@", bid, pname]);
        BOOL isMobileSMS = [bid isEqualToString:@"com.apple.MobileSMS"] || [pname isEqualToString:@"MobileSMS"];
        if (!isMobileSMS) {
            LogLine(@"not MobileSMS; inert");
            return;
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            LogLine(@"poll started");
            [NSTimer scheduledTimerWithTimeInterval:1.0 repeats:YES block:^(__unused NSTimer *t) { PollOnce(); }];
        });
    }
}
